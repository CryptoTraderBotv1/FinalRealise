<?php
include(dirname(__file__).'/config.php');
include(dirname(__file__).'/language.php');
session_start();

define('SDS_BLOCKED', 1);
define('SDS_DANGER', 2);
define('SDS_SUSPIC', 4);
define('SDS_OTHER', 8);

$echo = '';
$HTML = '';

## Убираем "работу" волшебных кавычек
if (get_magic_quotes_gpc()) {
  function stripslashes_deep($value) {
    $value = is_array($value) ? array_map('stripslashes_deep', $value) : stripslashes($value);
    return $value;
  }
  $_POST = array_map('stripslashes_deep', $_POST);
}

$HTML .= '<!DOCTYPE html>
<html>
<head>
<title>CopySites v.'.$config['ver'].' AdminPanel</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<script src="js/jquery-1.8.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style>
a {
color: #0649cf;
}
ul.nav a {
  text-decoration: none;
}
</style>
<script>
$(function() {
  $(\'body\').tooltip({
      selector: "[rel=tooltip]",
      placement: "top" 
  });
});
</script>

</head>
<body>';

################################################################################################################################
#### Сохранение пароля
################################################################################################################################
if (!file_exists(dirname(__FILE__).'/password')) {
  if (isset($_POST['action']) and $_POST['action'] == 'one' and !empty($_POST['pass'])) {
    $f = @fopen(dirname(__FILE__).'/password','w+');
    $fw = @fwrite($f,md5($_POST['pass']));
    @fclose($f);
    if ($fw) {
      $HTML .= '<div class="center" style="color: green;">Пароль успешно сохранен. В течении 5 секунд Вы будете перенаправлены в админ-панель.</div>';
    } else {
      $HTML .= '<div class="center" style="color: red;">Пароль сохранить не удалось по причине: Не удается записать файл password.</div>';
    }
    die('<meta http-equiv="refresh" content="5;URL=admin_panel.php">');
  }
  $HTML .= '<div class="center" style="color: green;">
  <font style="font-size: 19px;">Для использования админ-панели, пожалуйста, введите желаемый пароль:</font><br><br>
  <form action="" method="POST">
  <input name="action" value="one" type="hidden">
  <input name="pass" class="input_one"><br><br>
  <input type="submit" value="Продолжить" class="btn btn-primary" onclick="return confirm (\'Вы запомнили пароль? В дальнейшем он будет использоваться для авторизации в админ-панель!\r\n\')">
  </form>
  </div>';
  die();
}

$pass = @file_get_contents(dirname(__FILE__).'/password');
if (!$pass) die('Error password!');
if (isset($_POST['action']) && $_POST['action'] == 'auth' && !empty($_POST['pass'])) {
  if (md5($_POST['pass']) === $pass) {
    $_SESSION['auth'] = $pass;
    header('Location: admin_panel.php?action=main');
    die();
  } else {
    $HTML .= '<div class="container-fluid"><div class="row-fluid"><div class="span4">&nbsp;</div>
          <div class="span4"><br /><br /><br /><div class="alert alert-error">Неверный пароль!</div></div></div></div>';
  }
} elseif (!isset($_SESSION['auth']) || $_SESSION['auth'] !== $pass) {
  $HTML .= '<div class="container-fluid">
        <div class="row-fluid">
        <div class="span4">&nbsp;</div>
        <div class="span4">
          <br /><br /><br />
          <div class="well" style="text-align: center;">
            <h5>Введите пароль:</h5>
            <form action="" method="POST">
              <input type="hidden" name="action" value="auth" />
              <input type="password" name="pass" class="span7" /><br />
              <input type="submit" value="Войти" class="btn btn-primary" />
            </form>
          </div>
        </div>
        <div class="span4">&nbsp;</div>
        </div>';
} elseif ($_SESSION['auth'] === $pass) { # Если авторизованы
  require_once(dirname(__file__).'/function.php');
  $active = array(
    'main' => '',
    'replace' => '',
    'online' => '',
    'targets' => '',
    'block' => '',
    'danger' => '',
    'suspic' => '',
  );

  if (isset($_GET['action'])) {
    foreach ($active as $key => $value) $active[$key] = '';
    $active[$_GET['action']] = ' class="active"';
  }

  $HTML .= '<h3 style="text-align:center;">CopySites v.'.$config['ver'].' AdminPanel</h3>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="span2">

  <div class="well" style="max-width: 340px; padding: 8px 0;">
    <ul class="nav nav-list">
      <li class="nav-header">Главное меню</li>
      <li'.$active['main'].'><a href="admin_panel.php?action=main">Основные настройки</a></li>
      <li'.$active['replace'].'><a href="admin_panel.php?action=replace">Замена кода</a></li>
      <li'.$active['online'].'><a href="admin_panel.php?action=online">Прямой эфир</a></li>
      <li class="divider"></li>
      <li'.$active['block'].'><a href="admin_panel.php?action=block">Заблокированные</a></li>
      <li'.$active['danger'].'><a href="admin_panel.php?action=danger">Опасные</a></li>
      <li'.$active['suspic'].'><a href="admin_panel.php?action=suspic">Подозрительные</a></li>
      <li class="divider"></li>
      <li'.$active['targets'].'><a href="admin_panel.php?action=targets">Цели</a></li>
      <li class="divider"></li>
      <li><a href="admin_panel.php?action=clean" onclick="return confirm (\'Вы действительно хотите очистить кеш?\r\n\')">Очистить кеш</a></li>
      
	  <li><a href="." target="_blank">Перейти на сайт</a></li>
      <li class="divider"></li>
      <li><a href="admin_panel.php?action=exit">Выход</a></li>
	  
    </ul>
  </div>

      </div>
      <div class="span10">
  ';

################################################################################################################################
#### Выход из аккуанта
################################################################################################################################
  if (isset($_GET['action']) && $_GET['action'] == 'exit') { 
    unset($_SESSION['auth']);
    header('Location: admin_panel.php');
    die();
  } elseif (isset($_GET['action']) && $_GET['action'] == 'targets') { 
################################################################################################################################
#### Страница настройки целей
################################################################################################################################
    if (isset($_POST['subaction']) && $_POST['subaction'] == 'newtarget') { # Добавление цели
      if (isset($_POST['title']) && trim($_POST['title']) != '' && isset($_POST['url']) && trim($_POST['url']) != '' && isset($_POST['code']) && trim($_POST['code']) != '') {
        $targets = @unserialize(file_get_contents(dirname(__FILE__).'/targets.txt'));
        if (!is_array($targets)) $targets = array();
        $targets[] = array(
          str_replace('\'', '\\\'', str_replace('\\', '\\\\', $_POST['title'])),
          '/'.ltrim($_POST['url'], '/'),
          ltrim($_POST['code'], '?')
        );
        $targets = serialize($targets);
      	$f = fopen(dirname(__FILE__).'/targets.txt', 'w+');
      	$fw = fwrite($f, $targets);
      	fclose($f);
        header('Location: admin_panel.php?action=targets');
        die();
      }
    } elseif (isset($_POST['subaction']) && $_POST['subaction'] == 'savetarget') { # Изменение цели
      if (isset($_POST['targetid']) && trim($_POST['targetid']) != '' && isset($_POST['title']) && trim($_POST['title']) != '' && isset($_POST['url']) && trim($_POST['url']) != '' && isset($_POST['code']) && trim($_POST['code']) != '') {
        $targets = @unserialize(file_get_contents(dirname(__FILE__).'/targets.txt'));
        $targets[(int)$_POST['targetid']] = array(
          str_replace('\'', '\\\'', str_replace('\\', '\\\\', $_POST['title'])),
          '/'.ltrim($_POST['url'], '/'),
          ltrim($_POST['code'], '?')
        );
        $targets = serialize($targets);
      	$f = fopen(dirname(__FILE__).'/targets.txt', 'w+');
      	$fw = fwrite($f, $targets);
      	fclose($f);
        header('Location: admin_panel.php?action=targets');
        die();
      }
    }
    
    if (isset($_GET['subaction']) && $_GET['subaction'] == 'deletetarget') { # Удаление цели
      if (isset($_GET['tid']) && is_numeric($_GET['tid'])) {
        $targets = @unserialize(file_get_contents(dirname(__FILE__).'/targets.txt'));
        $newtargets = array();
        foreach ($targets as $key => $target) {
          if ($key == (int)$_GET['tid']) continue;
          $newtargets[] = $target;
        }
        $newtargets = serialize($newtargets);
      	$f = fopen(dirname(__FILE__).'/targets.txt', 'w+');
      	$fw = fwrite($f, $newtargets);
      	fclose($f);
        header('Location: admin_panel.php?action=targets');
        die();
      }
    }
    
    $targets = @unserialize(file_get_contents(dirname(__FILE__).'/targets.txt'));
    if (is_array($targets) && count($targets) > 0) {
      $HTML .= '<br /><table class="table table-hover table-bordered table-condensed table-striped">';
      $HTML .= '<thead><tr><th>Название</th><th>Исходный URL</th><th>Добавочный код</th><th>Полная реф-ссылка</th><th></th></tr></thead><tbody>';
      foreach ($targets as $key => $target) {
        $HTML .= '<tr>
        <td>'.$target[0].'</td>
        <td>'.$target[1].'</td>
        <td>'.$target[2].'</td>
        <td><a href="http://'.$config['my_domain'].$target[1].(strpos($target[1], '?') === false ? '?' : '&').$target[2].'" target="_blank">http://'.$config['my_domain'].$target[1].(strpos($target[1], '?') === false ? '?' : '&').$target[2].'</a></td>
        <td><a href="#edittarget" data-toggle="modal" rel="tooltip" title="Изменить цель" class="btn btn-mini" onclick="initEditTargetWindow('.$key.', \''.$target[0].'\', \''.$target[1].'\', \''.$target[2].'\');"><i class="icon-edit"></i></a>&nbsp;<a href="admin_panel.php?action=targets&subaction=deletetarget&tid='.$key.'" class="btn btn-mini" rel="tooltip" title="Удалить цель" onclick="return confirm (\'Вы уверены?\')"><i class="icon-remove"></i></a></td></tr>';
      }
      $HTML .= '</table>';
    }
    $HTML .= '<a href="#newtarget" data-toggle="modal" class="btn">Добавить цель</a>';
    $HTML .= '<div id="newtarget" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 id="myModalLabel1">Добавить цель</h4>
      </div>
      <div class="modal-body">
        <form action="admin_panel.php?action=targets" method="post">
          <input type="hidden" name="subaction" value="newtarget" />
          <label>Название</label>
          <input type="text" name="title" class="span12" />
          <label>Исходный URL <small>(без имени хоста, например "<code>/page123.html</code>")</small></label>
          <input type="text" name="url" class="span12" value="/" />
          <label>Добавочный код <small>(без знака вопроса, например "<code>id=123</code>")</small></label>
          <input type="text" name="code" class="span12" />
      </div>
      <div class="modal-footer">
          <button class="btn btn-primary" type="submit">Добавить</button>
          <a class="btn" data-dismiss="modal" aria-hidden="true">Отмена</a>
        </form>
      </div>
    </div>';
    $HTML .= '<div id="edittarget" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 id="myModalLabel2">Изменить цель</h4>
      </div>
      <div class="modal-body">
        <form action="admin_panel.php?action=targets" method="post">
          <input type="hidden" name="subaction" value="savetarget" />
          <input type="hidden" name="targetid" value="" id="targetidvalue" />
          <label>Название</label>
          <input type="text" name="title" class="span12" id="titleEdit" />
          <label>Исходный URL <small>(без имени хоста, например "<code>/page123.html</code>")</small></label>
          <input type="text" name="url" class="span12" id="urlEdit" value="/" />
          <label>Добавочный код <small>(без знака вопроса, например "<code>id=123</code>")</small></label>
          <input type="text" name="code" class="span12" id="codeEdit" />
      </div>
      <div class="modal-footer">
          <a class="btn" data-dismiss="modal" aria-hidden="true">Отмена</a>
          <button class="btn btn-primary" type="submit">Сохранить</button>
        </form>
      </div>
    </div>';
    $HTML .= '<script>
function initEditTargetWindow(id, title, url, code) {
  $(\'#titleEdit\').val(title);
  $(\'#urlEdit\').val(url);
  $(\'#codeEdit\').val(code);
  $(\'#targetidvalue\').val(id);
};
</script>';
  } elseif ( isset($_GET['action']) && $_GET['action'] == 'block' ) { 
################################################################################################################################
##### Страница настройки блокировки
################################################################################################################################
    if (isset($_POST['action']) && $_POST['action'] == 'saveblocks') { # Сохранение настроек блокировки
      $save = array(
				array(
	    		'group' => 'default',
	    		'ip' => array(),
	    		'host_referer' => array(),
	    		'referer' => array(),
	        'diapazon' => array(),
	        'country' => array(),
	        'country_block' => '1',
	        'city' => array(),
	        'city_block' => '1',
	    	)
			);
      foreach ($_POST['groups'] as $key => $value) {
      	$ip = strval(trim($_POST['ip'][$key]));
      	$ip = preg_replace('#\r#Uis', '', $ip);
      	$ip = explode("\n", $ip);
      	if ( count($ip) == 0 ) {
      		$ip = array();
      	}
      	
      	$host_referer = strval(trim($_POST['host_referer'][$key]));
      	$host_referer = strtolower(preg_replace('#\r#Uis', '', $host_referer));
      	$host_referer = explode("\n", $host_referer);
      	if ( count($host_referer) == 0 ) {
      		$host_referer = array();
      	}
      	
      	$referer = strval(trim($_POST['referer'][$key]));
      	$referer = strtolower(preg_replace('#\r#Uis', '', $referer));
      	$referer = explode("\n", $referer);
      	if ( count($referer) == 0 ) {
      		$referer = array();
      	}
        
        $diapazon = strval(trim($_POST['diapazon'][$key]));
      	$diapazon = strtolower(preg_replace('#\r#Uis', '', $diapazon));
      	$diapazon = explode("\n", $diapazon);
      	if ( count($diapazon) == 0 ) {
      		$diapazon = array();
      	}
        
        $country = strval(trim($_POST['country'][$key]));
      	$country = strtolower(preg_replace('#\r#Uis', '', $country));
      	$country = explode("\n", $country);
      	if ( count($country) == 0 ) {
      		$country = array();
      	}
        
        $city = strval(trim($_POST['city'][$key]));
      	$city = explode("\n", $city);
      	if ( count($city) == 0 ) {
      		$city = array();
      	}
				foreach ($city as $kkk => $vvv) {
					$city[$kkk] = trim($vvv);
				}
        $save[$key] = array(
      		'group' => $value,
      		'ip' => $ip,
      		'host_referer' => $host_referer,
      		'referer' => $referer,
          'diapazon' => $diapazon,
          'country' => $country,
          'country_block' => $_POST['country_block'][$key],
          'city' => $city,
          'city_block' => $_POST['city_block'][$key],
      	);
      }
    	
    	$save = serialize($save);
    	$f = fopen(dirname(__FILE__) . '/block.txt', 'w+');
    	$fw = fwrite($f, $save);
    	fclose($f);
    	
    	if ($fw) $HTML .= '<div class="alert alert-success">Списки сохранены.</div>';
    	  else $HTML .= '<div class="alert alert-error">Списки не сохранены.</div>';
    } elseif (isset($_POST['action']) && $_POST['action'] == 'newgroup') { # Новый ярлык
      if (isset($_POST['title']) && trim($_POST['title']) != '' && trim($_POST['title']) != 'default' && trim($_POST['title']) != 'Без ярлыка') {
        $blocks = @unserialize(file_get_contents(dirname(__FILE__).'/block.txt'));
        if (!is_array($blocks)) $blocks = array(array('group' => $_POST['title']));
        else $blocks[] = array('group' => $_POST['title'], 'ip' => array(), 'host_referer' => array(), 'referer' => array(), 'diapazon' => array(), 'country' => array(), 'country_block' => '', 'city' => array(), 'city_block' => '');
        $blocks = serialize($blocks);
      	$f = fopen(dirname(__FILE__).'/block.txt', 'w+');
      	$fw = fwrite($f, $blocks);
      	fclose($f);
        header('Location: admin_panel.php?action=block');
        die();
      }
    } elseif (isset($_POST['action']) && $_POST['action'] == 'editgroup') { # Переименование ярлыка
      if (isset($_POST['title']) && isset($_POST['groupid']) && trim($_POST['title']) != '' && is_numeric($_POST['groupid']) && trim($_POST['title']) != 'default' && trim($_POST['title']) != 'Без ярлыка') {
        $blocks = @unserialize(file_get_contents(dirname(__FILE__).'/block.txt'));
        $blocks[(int)$_POST['groupid']]['group'] = trim($_POST['title']);
        $blocks = serialize($blocks);
      	$f = fopen(dirname(__FILE__).'/block.txt', 'w+');
      	$fw = fwrite($f, $blocks);
      	fclose($f);
        header('Location: admin_panel.php?action=block');
        die();
      }
    }
    
    if (isset($_GET['subaction']) && $_GET['subaction'] == 'deletegroup') { # Удаление ярлыка
      if (isset($_GET['gid']) && is_numeric($_GET['gid'])) {
        $blocks = @unserialize(file_get_contents(dirname(__FILE__).'/block.txt'));
        $newblocks = array();
        foreach ($blocks as $key => $block) {
          if ($key == (int)$_GET['gid']) continue;
          $newblocks[] = $block;
        }
        $newblocks = serialize($newblocks);
      	$f = fopen(dirname(__FILE__).'/block.txt', 'w+');
      	$fw = fwrite($f, $newblocks);
      	fclose($f);
        header('Location: admin_panel.php?action=block');
        die();
      }
    }
    
    $blocks = @unserialize(file_get_contents(dirname(__FILE__).'/block.txt'));
    if (!is_array($blocks)) $blocks = array(array('group' => 'default'));

    $HTML .= '<div class="well"><ul class="nav nav-pills" id="ligroups" style="margin-bottom:0;">';
    $first = true;
    foreach ($blocks as $key => $block) {
      $liclass = '';
      if ($first) {
        $liclass = ' class="active"';
        $first = false;
      }
      $HTML .= '<li'.$liclass.'><a href="#tab'.$key.'" data-toggle="tab" id="agroup'.$key.'">'.($block['group'] == 'default' ? 'Без ярлыка' : $block['group']).'</a></li>';
    }
    $HTML .= '&nbsp;<a href="#newgroup" data-toggle="modal" class="btn" rel="tooltip" title="Добавить ярлык"><i class="icon-plus"></i></a></ul></div>';
    $HTML .= '<form action="admin_panel.php?action=block" method="post">';
    $HTML .= '<input type="hidden" name="action" value="saveblocks" />';
    $HTML .= '<div class="tab-content">';
    $first = true;
    foreach ($blocks as $key => $block) {
      $divclass = '';
      if ($first) {
        $divclass = ' active';
        $first = false;
      }
      $HTML .= '<div class="tab-pane'.$divclass.'" id="tab'.$key.'">';
      $HTML .= '<input type="hidden" name="groups['.$key.']" value="'.$block['group'].'" />';
      if ($block['group'] != 'default') {
        $HTML .= '<a href="#editgroup" class="btn btn-mini" role="button" data-toggle="modal" onclick="initEditWindow('.$key.');">Переименовать ярлык</a>&nbsp;<a href="admin_panel.php?action=block&subaction=deletegroup&gid='.$key.'" class="btn btn-mini" onclick="return confirm (\'Вы уверены?\')">Удалить ярлык</a><br /><br />';
      }
      $HTML .= '<label>Блокировка по IP:</label>
      <textarea rows="9" name="ip['.$key.']" class="span4">'.@implode("\r\n", $block['ip']).'</textarea><br /><br />

      <label>Блокировка по хосту рефера:</label>
      <textarea rows="9" name="host_referer['.$key.']" class="span4">'.@implode("\r\n", $block['host_referer']).'</textarea><br /><br />

      <label>Блокировка по реферу:</label>
      <textarea rows="9" name="referer['.$key.']" class="span4">'.@implode("\r\n", $block['referer']).'</textarea><br /><br />

      <label>Блокировка по диапазону:</label>
      <textarea rows="9" name="diapazon['.$key.']" class="span4">'.@implode("\r\n", $block['diapazon']).'</textarea><br /><br />

      <label>Блокировка по стране:</label>
      <label><input type="radio" name="country_block['.$key.']" value="1"'.((!isset($block['country_block']) || $block['country_block'] == '1') ? ' checked="true"' : '').'>&nbsp;блокировать указанные</label><label><input type="radio" name="country_block['.$key.']" value="2"'.((isset($block['country_block']) && $block['country_block'] == '2') ? ' checked="true"' : '').'>&nbsp;блокировать все, кроме указанных</label>
      <textarea rows="5" name="country['.$key.']" class="span4">'.@implode("\r\n", $block['country']).'</textarea><br /><br />

      <label>Блокировка по городу:</label>
      <label><input type="radio" name="city_block['.$key.']" value="1"'.((!isset($block['city_block']) || $block['city_block'] == '1') ? ' checked="true"' : '').'>&nbsp;блокировать указанные</label><label><input type="radio" name="city_block['.$key.']" value="2"'.((isset($block['city_block']) && $block['city_block'] == '2') ? ' checked="true"' : '').'>&nbsp;блокировать все, кроме указанных</label>
      <textarea rows="5" name="city['.$key.']" class="span4">'.@implode("\r\n", $block['city']).'</textarea><br /><br />';
      $HTML .= '</div>';
    }
    $HTML .= '<input type="submit" class="btn btn-primary" value="Сохранить списки" />';
    $HTML .= '</form>';
    $HTML .= '</div>';
    $HTML .= '<div id="newgroup" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 id="myModalLabel1">Добавить ярлык</h4>
      </div>
      <div class="modal-body">
        <form action="admin_panel.php?action=block" method="post">
          <input type="hidden" name="action" value="newgroup" />
          <label>Название</label>
          <input type="text" name="title" class="span12" />
      </div>
      <div class="modal-footer">
          <button class="btn btn-primary" type="submit">Добавить</button>
          <a class="btn" data-dismiss="modal" aria-hidden="true">Отмена</a>
        </form>
      </div>
    </div>';
    $HTML .= '<div id="editgroup" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 id="myModalLabel2">Переименовать ярлык</h4>
      </div>
      <div class="modal-body">
        <form action="admin_panel.php?action=block" method="post">
          <input type="hidden" name="action" value="editgroup" />
          <input type="hidden" name="groupid" value="" id="groupidvalue" />
          <label>Новое название</label>
          <input type="text" name="title" class="span12" id="editgrouptitle" />
      </div>
      <div class="modal-footer">
          <a class="btn" data-dismiss="modal" aria-hidden="true">Отмена</a>
          <button class="btn btn-primary" type="submit">Сохранить</button>
        </form>
      </div>
    </div>';
    $HTML .= '<script>
function initEditWindow(id) {
  $(\'#editgrouptitle\').val($(\'#agroup\' + id).text());
  $(\'#groupidvalue\').val(id);
};
</script>';
  } elseif ( isset($_GET['action']) && $_GET['action'] == 'danger' ) { 
################################################################################################################################
#### Опасные
################################################################################################################################
    if (isset($_POST['action']) && $_POST['action'] == 'save_danger') { # Сохранение опасных
      $save = array();
      foreach ($_POST['groups'] as $key => $value) {
      	$ip = strval(trim($_POST['ip'][$key]));
      	$ip = preg_replace('#\r#Uis', '', $ip);
      	$ip = explode("\n", $ip);
      	if ( count($ip) == 0 ) {
      		$ip = array();
      	}
      	
      	$host_referer = strval(trim($_POST['host_referer'][$key]));
      	$host_referer = strtolower(preg_replace('#\r#Uis', '', $host_referer));
      	$host_referer = explode("\n", $host_referer);
      	if ( count($host_referer) == 0 ) {
      		$host_referer = array();
      	}
      	
      	$referer = strval(trim($_POST['referer'][$key]));
      	$referer = strtolower(preg_replace('#\r#Uis', '', $referer));
      	$referer = explode("\n", $referer);
      	if ( count($referer) == 0 ) {
      		$referer = array();
      	}
        
        $diapazon = strval(trim($_POST['diapazon'][$key]));
      	$diapazon = strtolower(preg_replace('#\r#Uis', '', $diapazon));
      	$diapazon = explode("\n", $diapazon);
      	if ( count($diapazon) == 0 ) {
      		$diapazon = array();
      	}

        $save[$key] = array(
      		'group' => $value,
      		'ip' => $ip,
      		'host_referer' => $host_referer,
      		'referer' => $referer,
          'diapazon' => $diapazon,
      	);
      }
    	
    	$save = serialize($save);
    	$f = fopen(dirname(__FILE__) . '/danger.txt', 'w+');
    	$fw = fwrite($f, $save);
    	fclose($f);
    	
    	if ($fw) $HTML .= '<div class="alert alert-success">Списки сохранены.</div>';
    	  else $HTML .= '<div class="alert alert-error">Списки не сохранены.</div>';
    } elseif (isset($_POST['action']) && $_POST['action'] == 'newgroup') { # Новый ярлык
      if (isset($_POST['title']) && trim($_POST['title']) != '' && trim($_POST['title']) != 'default' && trim($_POST['title']) != 'Без ярлыка') {
        $danger = @unserialize(file_get_contents(dirname(__FILE__).'/danger.txt'));
        if (!is_array($danger)) $danger = array(array('group' => $_POST['title'], 'ip' => array(), 'host_referer' => array(), 'referer' => array(), 'diapazon' => array()));
        else $danger[] = array('group' => $_POST['title']);
        $danger = serialize($danger);
      	$f = fopen(dirname(__FILE__).'/danger.txt', 'w+');
      	$fw = fwrite($f, $danger);
      	fclose($f);
        header('Location: admin_panel.php?action=danger');
        die();
      }
    } elseif (isset($_POST['action']) && $_POST['action'] == 'editgroup') { # Переименование ярлыка
      if (isset($_POST['title']) && isset($_POST['groupid']) && trim($_POST['title']) != '' && is_numeric($_POST['groupid']) && trim($_POST['title']) != 'default' && trim($_POST['title']) != 'Без ярлыка') {
        $danger = @unserialize(file_get_contents(dirname(__FILE__).'/danger.txt'));
        $danger[(int)$_POST['groupid']]['group'] = trim($_POST['title']);
        $danger = serialize($danger);
      	$f = fopen(dirname(__FILE__).'/danger.txt', 'w+');
      	$fw = fwrite($f, $danger);
      	fclose($f);
        header('Location: admin_panel.php?action=danger');
        die();
      }
    }
    
    if (isset($_GET['subaction']) && $_GET['subaction'] == 'deletegroup') { # Удаление ярлыка
      if (isset($_GET['gid']) && is_numeric($_GET['gid'])) {
        $danger = @unserialize(file_get_contents(dirname(__FILE__).'/danger.txt'));
        $newdanger = array();
        foreach ($danger as $key => $value) {
          if ($key == (int)$_GET['gid']) continue;
          $newdanger[] = $value;
        }
        $newdanger = serialize($newdanger);
      	$f = fopen(dirname(__FILE__).'/danger.txt', 'w+');
      	$fw = fwrite($f, $newdanger);
      	fclose($f);
        header('Location: admin_panel.php?action=danger');
        die();
      }
    }
    
    $danger = @unserialize(file_get_contents(dirname(__FILE__).'/danger.txt'));
    if (!is_array($danger)) $danger = array(array('group' => 'default'));

    $HTML .= '<div class="well"><ul class="nav nav-pills" id="ligroups" style="margin-bottom:0;">';
    $first = true;
    foreach ($danger as $key => $value) {
      $liclass = '';
      if ($first) {
        $liclass = ' class="active"';
        $first = false;
      }
      $HTML .= '<li'.$liclass.'><a href="#tab'.$key.'" data-toggle="tab" id="agroup'.$key.'">'.($value['group'] == 'default' ? 'Без ярлыка' : $value['group']).'</a></li>';
    }
    $HTML .= '&nbsp;<a href="#newgroup" data-toggle="modal" class="btn" rel="tooltip" title="Добавить ярлык"><i class="icon-plus"></i></a></ul></div>';
    $HTML .= '<form action="admin_panel.php?action=danger" method="post">';
    $HTML .= '<input type="hidden" name="action" value="save_danger" />';
    $HTML .= '<div class="tab-content">';
    $first = true;
    foreach ($danger as $key => $value) {
      $divclass = '';
      if ($first) {
        $divclass = ' active';
        $first = false;
      }
      $HTML .= '<div class="tab-pane'.$divclass.'" id="tab'.$key.'">';
      $HTML .= '<input type="hidden" name="groups['.$key.']" value="'.$value['group'].'" />';
      if ($value['group'] != 'default') {
        $HTML .= '<a href="#editgroup" class="btn btn-mini" role="button" data-toggle="modal" onclick="initEditWindow('.$key.');">Переименовать ярлык</a>&nbsp;<a href="admin_panel.php?action=danger&subaction=deletegroup&gid='.$key.'" class="btn btn-mini" onclick="return confirm (\'Вы уверены?\')">Удалить ярлык</a><br /><br />';
      }
      $HTML .= '<label>Опасные по IP:</label>
      <textarea rows="9" name="ip['.$key.']" class="span4">'.@implode("\r\n", $value['ip']).'</textarea><br /><br />

      <label>Опасные по хосту рефера:</label>
      <textarea rows="9" name="host_referer['.$key.']" class="span4">'.@implode("\r\n", $value['host_referer']).'</textarea><br /><br />

      <label>Опасные по реферу:</label>
      <textarea rows="9" name="referer['.$key.']" class="span4">'.@implode("\r\n", $value['referer']).'</textarea><br /><br />

      <label>Опасные по диапазону:</label>
      <textarea rows="9" name="diapazon['.$key.']" class="span4">'.@implode("\r\n", $value['diapazon']).'</textarea><br /><br />';
      $HTML .= '</div>';
    }
    $HTML .= '<input type="submit" class="btn btn-primary" value="Сохранить списки" />';
    $HTML .= '</form>';
    $HTML .= '</div>';
    $HTML .= '<div id="newgroup" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 id="myModalLabel1">Добавить ярлык</h4>
      </div>
      <div class="modal-body">
        <form action="admin_panel.php?action=danger" method="post">
          <input type="hidden" name="action" value="newgroup" />
          <label>Название</label>
          <input type="text" name="title" class="span12" />
      </div>
      <div class="modal-footer">
          <button class="btn btn-primary" type="submit">Добавить</button>
          <a class="btn" data-dismiss="modal" aria-hidden="true">Отмена</a>
        </form>
      </div>
    </div>';
    $HTML .= '<div id="editgroup" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 id="myModalLabel2">Переименовать ярлык</h4>
      </div>
      <div class="modal-body">
        <form action="admin_panel.php?action=danger" method="post">
          <input type="hidden" name="action" value="editgroup" />
          <input type="hidden" name="groupid" value="" id="groupidvalue" />
          <label>Новое название</label>
          <input type="text" name="title" class="span12" id="editgrouptitle" />
      </div>
      <div class="modal-footer">
          <a class="btn" data-dismiss="modal" aria-hidden="true">Отмена</a>
          <button class="btn btn-primary" type="submit">Сохранить</button>
        </form>
      </div>
    </div>';
    $HTML .= '<script>
function initEditWindow(id) {
  $(\'#editgrouptitle\').val($(\'#agroup\' + id).text());
  $(\'#groupidvalue\').val(id);
};
</script>';
  } elseif (isset($_GET['action']) && $_GET['action'] == 'suspic') {
################################################################################################################################
# Подозрительные
################################################################################################################################
    if (isset($_POST['action']) && $_POST['action'] == 'save_suspic') { # Сохранение подозрительных
      $save = array();
      foreach ($_POST['groups'] as $key => $value) {
      	$ip = strval(trim($_POST['ip'][$key]));
      	$ip = preg_replace('#\r#Uis', '', $ip);
      	$ip = explode("\n", $ip);
      	if ( count($ip) == 0 ) {
      		$ip = array();
      	}
      	
      	$host_referer = strval(trim($_POST['host_referer'][$key]));
      	$host_referer = strtolower(preg_replace('#\r#Uis', '', $host_referer));
      	$host_referer = explode("\n", $host_referer);
      	if ( count($host_referer) == 0 ) {
      		$host_referer = array();
      	}
      	
      	$referer = strval(trim($_POST['referer'][$key]));
      	$referer = strtolower(preg_replace('#\r#Uis', '', $referer));
      	$referer = explode("\n", $referer);
      	if ( count($referer) == 0 ) {
      		$referer = array();
      	}

        $save[$key] = array(
      		'group' => $value,
      		'ip' => $ip,
      		'host_referer' => $host_referer,
      		'referer' => $referer,
      	);
      }
    	
    	$save = serialize($save);
    	$f = fopen(dirname(__FILE__) . '/suspic.txt', 'w+');
    	$fw = fwrite($f, $save);
    	fclose($f);
    	
    	if ($fw) $HTML .= '<div class="alert alert-success">Списки сохранены.</div>';
    	  else $HTML .= '<div class="alert alert-error">Списки не сохранены.</div>';
    } elseif (isset($_POST['action']) && $_POST['action'] == 'newgroup') { # Новый ярлык
      if (isset($_POST['title']) && trim($_POST['title']) != '' && trim($_POST['title']) != 'default' && trim($_POST['title']) != 'Без ярлыка') {
        $suspic = @unserialize(file_get_contents(dirname(__FILE__).'/suspic.txt'));
        if (!is_array($suspic)) $suspic = array(array('group' => $_POST['title']));
        else $suspic[] = array('group' => $_POST['title'], 'ip' => array(), 'host_referer' => array(), 'referer' => array());
        $suspic = serialize($suspic);
      	$f = fopen(dirname(__FILE__).'/suspic.txt', 'w+');
      	$fw = fwrite($f, $suspic);
      	fclose($f);
        header('Location: admin_panel.php?action=suspic');
        die();
      }
    } elseif (isset($_POST['action']) && $_POST['action'] == 'editgroup') { # Переименование ярлыка
      if (isset($_POST['title']) && isset($_POST['groupid']) && trim($_POST['title']) != '' && is_numeric($_POST['groupid']) && trim($_POST['title']) != 'default' && trim($_POST['title']) != 'Без ярлыка') {
        $suspic = @unserialize(file_get_contents(dirname(__FILE__).'/suspic.txt'));
        $suspic[(int)$_POST['groupid']]['group'] = trim($_POST['title']);
        $suspic = serialize($suspic);
      	$f = fopen(dirname(__FILE__).'/suspic.txt', 'w+');
      	$fw = fwrite($f, $suspic);
      	fclose($f);
        header('Location: admin_panel.php?action=suspic');
        die();
      }
    }
    
    if (isset($_GET['subaction']) && $_GET['subaction'] == 'deletegroup') { # Удаление ярлыка
      if (isset($_GET['gid']) && is_numeric($_GET['gid'])) {
        $suspic = @unserialize(file_get_contents(dirname(__FILE__).'/suspic.txt'));
        $newsuspic = array();
        foreach ($suspic as $key => $value) {
          if ($key == (int)$_GET['gid']) continue;
          $newsuspic[] = $value;
        }
        $newsuspic = serialize($newsuspic);
      	$f = fopen(dirname(__FILE__).'/suspic.txt', 'w+');
      	$fw = fwrite($f, $newsuspic);
      	fclose($f);
        header('Location: admin_panel.php?action=suspic');
        die();
      }
    }
    
    $suspic = @unserialize(file_get_contents(dirname(__FILE__).'/suspic.txt'));
    if (!is_array($suspic)) $suspic = array(array('group' => 'default'));

    $HTML .= '<div class="well"><ul class="nav nav-pills" id="ligroups" style="margin-bottom:0;">';
    $first = true;
    foreach ($suspic as $key => $value) {
      $liclass = '';
      if ($first) {
        $liclass = ' class="active"';
        $first = false;
      }
      $HTML .= '<li'.$liclass.'><a href="#tab'.$key.'" data-toggle="tab" id="agroup'.$key.'">'.($value['group'] == 'default' ? 'Без ярлыка' : $value['group']).'</a></li>';
    }
    $HTML .= '&nbsp;<a href="#newgroup" data-toggle="modal" class="btn" rel="tooltip" title="Добавить ярлык"><i class="icon-plus"></i></a></ul></div>';
    $HTML .= '<form action="admin_panel.php?action=suspic" method="post">';
    $HTML .= '<input type="hidden" name="action" value="save_suspic" />';
    $HTML .= '<div class="tab-content">';
    $first = true;
    foreach ($suspic as $key => $value) {
      $divclass = '';
      if ($first) {
        $divclass = ' active';
        $first = false;
      }
      $HTML .= '<div class="tab-pane'.$divclass.'" id="tab'.$key.'">';
      $HTML .= '<input type="hidden" name="groups['.$key.']" value="'.$value['group'].'" />';
      if ($value['group'] != 'default') {
        $HTML .= '<a href="#editgroup" class="btn btn-mini" role="button" data-toggle="modal" onclick="initEditWindow('.$key.');">Переименовать ярлык</a>&nbsp;<a href="admin_panel.php?action=suspic&subaction=deletegroup&gid='.$key.'" class="btn btn-mini" onclick="return confirm (\'Вы уверены?\')">Удалить ярлык</a><br /><br />';
      }
      $HTML .= '<label>Подозрительные по IP:</label>
      <textarea rows="9" name="ip['.$key.']" class="span4">'.@implode("\r\n", $value['ip']).'</textarea><br /><br />

      <label>Подозрительные по хосту рефера:</label>
      <textarea rows="9" name="host_referer['.$key.']" class="span4">'.@implode("\r\n", $value['host_referer']).'</textarea><br /><br />

      <label>Подозрительные по реферу:</label>
      <textarea rows="9" name="referer['.$key.']" class="span4">'.@implode("\r\n", $value['referer']).'</textarea><br /><br />';
      $HTML .= '</div>';
    }
    $HTML .= '<input type="submit" class="btn btn-primary" value="Сохранить списки" />';
    $HTML .= '</form>';
    $HTML .= '</div>';
    $HTML .= '<div id="newgroup" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 id="myModalLabel1">Добавить ярлык</h4>
      </div>
      <div class="modal-body">
        <form action="admin_panel.php?action=suspic" method="post">
          <input type="hidden" name="action" value="newgroup" />
          <label>Название</label>
          <input type="text" name="title" class="span12" />
      </div>
      <div class="modal-footer">
          <button class="btn btn-primary" type="submit">Добавить</button>
          <a class="btn" data-dismiss="modal" aria-hidden="true">Отмена</a>
        </form>
      </div>
    </div>';
    $HTML .= '<div id="editgroup" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 id="myModalLabel2">Переименовать ярлык</h4>
      </div>
      <div class="modal-body">
        <form action="admin_panel.php?action=suspic" method="post">
          <input type="hidden" name="action" value="editgroup" />
          <input type="hidden" name="groupid" value="" id="groupidvalue" />
          <label>Новое название</label>
          <input type="text" name="title" class="span12" id="editgrouptitle" />
      </div>
      <div class="modal-footer">
          <a class="btn" data-dismiss="modal" aria-hidden="true">Отмена</a>
          <button class="btn btn-primary" type="submit">Сохранить</button>
        </form>
      </div>
    </div>';
    $HTML .= '<script>
function initEditWindow(id) {
  $(\'#editgrouptitle\').val($(\'#agroup\' + id).text());
  $(\'#groupidvalue\').val(id);
};
</script>';
  } elseif (isset($_GET['action']) && $_GET['action'] == 'online') {
################################################################################################################################
# Прямой эфир
################################################################################################################################
    if (isset($_GET['subaction']) && $_GET['subaction'] == 'block_ip') {
      $block0 = @unserialize(file_get_contents(dirname(__FILE__) . '/block.txt'));
      $already_blocked = false;
      foreach ($block0 as $key => $block) {
        if (in_array($_POST['ip'], $block['ip'])) {
          $already_blocked = true;
          break;
        }
      }
      if (!$already_blocked) {
        $block0[(int)$_POST['groupid']]['ip'][] = $_POST['ip'];
      	$block0 = serialize($block0);
      	$f = fopen(dirname(__FILE__) . '/block.txt', 'w+');
      	$fw = fwrite($f, $block0);
      	fclose($f);
      	
      	if ( $fw ) {
      		$HTML .= '<div class="alert alert-success">Адрес заблокирован.</div>';
      	} else {
      		$HTML .= '<div class="alert alert-error">Адрес не заблокирован.</div>';
      	}
      } else {
        $HTML .= '<div class="alert alert-error">Такой адрес уже заблокирован.</div>';
      }
    } elseif (isset($_GET['subaction']) && $_GET['subaction'] == 'suspic_ip') {
      $block0 = @unserialize(file_get_contents(dirname(__FILE__) . '/suspic.txt'));
      $already_suspic = false;
      foreach ($block0 as $key => $block) {
        if (isset($block['ip']) && in_array($_POST['ip'], $block['ip'])) {
          $already_suspic = true;
          break;
        }
      }
      if (!$already_suspic) {
        $block0[(int)$_POST['groupid']]['ip'][] = $_POST['ip'];
      	$block0 = serialize($block0);
      	$f = fopen(dirname(__FILE__) . '/suspic.txt', 'w+');
      	$fw = fwrite($f, $block0);
      	fclose($f);
      	
      	if ($fw) {
      		$HTML .= '<div class="alert alert-success">Адрес добавлен в "подозрительные".</div>';
      	} else {
      		$HTML .= '<div class="alert alert-error">Адрес не добавлен.</div>';
      	}
      } else {
        $HTML .= '<div class="alert alert-error">Такой адрес уже в "подозрительных".</div>';
      }
    } elseif (isset($_GET['subaction']) && $_GET['subaction'] == 'danger_ip') {
      $block0 = @unserialize(file_get_contents(dirname(__FILE__) . '/danger.txt'));
      $already_danger = false;
      foreach ($block0 as $key => $block) {
        if (isset($block['ip']) && in_array($_POST['ip'], $block['ip'])) {
          $already_danger = true;
          break;
        }
      }
      if (!$already_danger) {
        $block0[(int)$_POST['groupid']]['ip'][] = $_POST['ip'];
      	$block0 = serialize($block0);
      	$f = fopen(dirname(__FILE__) . '/danger.txt', 'w+');
      	$fw = fwrite($f, $block0);
      	fclose($f);
      	
      	if ( $fw ) {
      		$HTML .= '<div class="alert alert-success">Адрес добавлен в "опасные".</div>';
      	} else {
      		$HTML .= '<div class="alert alert-error">Адрес не добавлен.</div>';
      	}
      } else {
        $HTML .= '<div class="alert alert-error">Такой адрес уже в "опасных".</div>';
      }
    } elseif (isset($_GET['subaction']) && $_GET['subaction'] == 'block_country' && trim($_GET['c']) <> '') {
      $_GET['c'] = strtolower($_GET['c']);
      $block0 = @unserialize(file_get_contents(dirname(__FILE__) . '/block.txt'));
      $already_blocked = false;
      foreach ($block0 as $key => $block) {
        if (in_array($_GET['c'], $block['country'])) {
          $already_blocked = true;
          break;
        }
      }
      if (!$already_blocked) {
        $block0[0]['country'][] = $_GET['c'];
      	$block0 = serialize($block0);
      	$f = fopen(dirname(__FILE__) . '/block.txt', 'w+');
      	$fw = fwrite($f, $block0);
      	fclose($f);
      	
      	if ( $fw ) {
      		$HTML .= '<div class="alert alert-success">Страна заблокирована.</div>';
      	} else {
      		$HTML .= '<div class="alert alert-error">Страна не заблокирована.</div>';
      	}
      } else {
        $HTML .= '<div class="alert alert-error">Такая страна уже заблокирована.</div>';
      }
    } elseif (isset($_GET['subaction']) && $_GET['subaction'] == 'block_city' && trim($_POST['c']) <> '') {
      //$_POST['c'] = strtolower($_POST['c']);
      $block0 = @unserialize(file_get_contents(dirname(__FILE__) . '/block.txt'));
      $already_blocked = false;
      foreach ($block0 as $key => $block) {
        if (in_array($_POST['c'], $block['city'])) {
          $already_blocked = true;
          break;
        }
      }
      if (!$already_blocked) {
        $block0[(int)$_POST['groupid']]['city'][] = $_POST['c'];
      	$block0 = serialize($block0);
      	$f = fopen(dirname(__FILE__) . '/block.txt', 'w+');
      	$fw = fwrite($f, $block0);
      	fclose($f);
      	
      	if ( $fw ) {
      		$HTML .= '<div class="alert alert-success">Город заблокирован.</div>';
      	} else {
      		$HTML .= '<div class="alert alert-error">Город не заблокирован.</div>';
      	}
      } else {
        $HTML .= '<div class="alert alert-error">Такой город уже заблокирован.</div>';
      }
    }
    
    if (isset($_POST['subaction']) && $_POST['subaction'] == 'filter_do') {
      $_SESSION['filter_target'] = (int)$_POST['filter_target'];
      $_SESSION['filter_group'] = $_POST['filter_group'];
    }
    if (isset($_GET['subaction']) && $_GET['subaction'] == 'nofilter') {
      $_SESSION['filter_target'] = -1;
      $_SESSION['filter_group'] = -1;
    }
    if (!isset($_SESSION['filter_target'])) $_SESSION['filter_target'] = -1;
    if (!isset($_SESSION['filter_group'])) $_SESSION['filter_group'] = -1;

    $targets = @unserialize(file_get_contents(dirname(__FILE__).'/targets.txt'));
    $block = @unserialize(file_get_contents(dirname(__FILE__).'/block.txt'));
    $groups = array();
    foreach ($block as $key => $value) {
      if ($value['group'] != 'default') $groups['1:'.$key] = $value['group'];
    }
    $danger = @unserialize(file_get_contents(dirname(__FILE__).'/danger.txt'));
    foreach ($danger as $key => $value) {
      if ($value['group'] != 'default') $groups['2:'.$key] = $value['group'];
    }
    $suspic = @unserialize(file_get_contents(dirname(__FILE__).'/suspic.txt'));
    foreach ($suspic as $key => $value) {
      if ($value['group'] != 'default') $groups['3:'.$key] = $value['group'];
    }
    $last_time = 0;
    $records_per_page = 100;
    $current_page = 1;
    
    $HTML .= '<div class="well">';
    $HTML .= '<form action="admin_panel.php?action=online" method="post" class="form-horizontal" style="margin:0;">';
    $HTML .= '<input type="hidden" name="subaction" value="filter_do" />';
    $HTML .= '<div class="control-group">';
    $HTML .= '<label class="control-label">Фильтр по цели:</label>';
    $HTML .= '<div class="controls">';
    $HTML .= '<select name="filter_target" class="span12">';
    $HTML .= '<option value="-1"'.(isset($_SESSION['filter_target']) && $_SESSION['filter_target'] == -1 ? ' selected' : '').'>Показывать все</option>';
    foreach ($targets as $key => $target) {
      $HTML .= '<option value="'.$key.'"'.(isset($_SESSION['filter_target']) && $_SESSION['filter_target'] == $key ? ' selected' : '').'>'.$target[0].' (http://'.$config['my_domain'].$target[1].(strpos($target[1], '?') === false ? '?' : '&').$target[2].')</option>';
    }
    $HTML .= '</select>';
    $HTML .= '</div>';
    $HTML .= '</div>';
    
    $HTML .= '<div class="control-group">';
    $HTML .= '<label class="control-label">Фильтр по ярлыку:</label>';
    $HTML .= '<div class="controls">';
    $HTML .= '<select name="filter_group" class="span12">';
    $HTML .= '<option value="-1"'.(isset($_SESSION['filter_group']) && $_SESSION['filter_group'] == -1 ? ' selected' : '').'>Показывать все</option>';
    foreach ($groups as $key => $group) {
      $HTML .= '<option value="'.$key.'"'.(isset($_SESSION['filter_group']) && $_SESSION['filter_group'] == $key ? ' selected' : '').'>'.$group.(substr($key, 0, 1) == '1' ? ' (Заблокированные)' : (substr($key, 0, 1) == '2' ? ' (Опасные)' : (substr($key, 0, 1) == '3' ? ' (Подозрительные)' : ''))).'</option>';
    }
    $HTML .= '</select>';
    $HTML .= '</div>';
    $HTML .= '</div>';
    $HTML .= '<div class="control-group" style="margin:0;"><div class="controls"><input type="submit" class="btn btn-primary" value="Применить фильтр" />&nbsp;<a class="btn" href="admin_panel.php?action=online&subaction=nofilter">Сбросить фильтр</a></div></div>';
    $HTML .= '</form>';
    $HTML .= '</div>';
    
    if (file_exists(dirname(__FILE__).'/save_data.txt')) {
      $save_data0 = file(dirname(__FILE__).'/save_data.txt');
      $save_data = array();
      foreach ($save_data0 as $key => $line) {
        if (trim($line) != '') {
          $pieces = explode(';', $line);
          if (isset($pieces[1])) {
            if (isset($_SESSION['filter_target']) && $_SESSION['filter_target'] != -1) {
              if (strpos($pieces[3], $targets[$_SESSION['filter_target']][2]) === false) continue;
            }
            if (isset($_SESSION['filter_group']) && $_SESSION['filter_group'] != -1) {
              $groups_ids = get_groups_ids(array($pieces[1], $pieces[2]));
              if (!in_array($_SESSION['filter_group'], $groups_ids)) continue;
            }
          }
          $save_data[] = $save_data0[$key];
        }
      }
      $save_data = array_reverse($save_data);
      if (isset($_GET['page']) && (int)$_GET['page'] > 0) $current_page = (int)$_GET['page'];
      $HTML .= '<table class="table table-hover table-bordered table-condensed" id="online_table">';
      $HTML .= '<thead><tr><th>Дата/время</th><th>IP</th><th>Страна/город</th><th>Реферер</th><th>Запрашиваемый адрес</th><th></th></tr></thead><tbody>';
      if (count($save_data) > 0) {
        $last_time = explode(';', $save_data[0]);
        $last_time = $last_time[0];
        for ($i=($current_page-1)*$records_per_page;$i<$current_page*$records_per_page;$i++) {
          if (!isset($save_data[$i])) continue;
          $line = $save_data[$i];
          $pieces = explode(';', $line);
          if (isset($pieces[1])) {
            require_once('geo.php');
            $geo = new Geo(array('ip' => $pieces[1], 'charset' => 'utf-8'));
            $geodata = $geo->get_value();
            $in_block = block(array($pieces[1], $pieces[2]));
            $in_danger = danger(array($pieces[1], $pieces[2]));
            $in_suspic = suspicious(array($pieces[1], $pieces[2]));
            $row_style = ' class="success"';
            if (substr($pieces[1], 0, 7) == '255.255') $mask_founded = true; else $mask_founded = false;
            if ($in_block || $mask_founded) $row_style = ' class="error"'; elseif ($in_danger || $in_suspic) $row_style = ' class="warning"';
            $notices = array();
            $groups_ids = get_groups_ids(array($pieces[1], $pieces[2]));
            if ($in_block) {
              $gggr = array();
              foreach ($groups_ids as $group_id) {
                if ($group_id != '1:0' && substr($group_id, 0, 1) == '1') $gggr[] = '"'.$groups[$group_id].'"';
              }
              $notices[] = '<span class="label label-important">Заблокированный.'.(count($gggr) > 0 ? ' Ярлык '.implode(', ', $gggr) : '').'</span>';
            }
            if ($mask_founded) $notices[] = '<span class="label label-important">IP похож на маску</span>';
            if ($in_danger) {
              $gggr = array();
              foreach ($groups_ids as $group_id) {
                if ($group_id != '2:0' && substr($group_id, 0, 1) == '2') $gggr[] = '"'.$groups[$group_id].'"';
              }
              $notices[] = '<span class="label label-warning">Опасный.'.(count($gggr) > 0 ? ' Ярлык '.implode(', ', $gggr) : '').'</span>';
            }
            if ($in_suspic) {
              $gggr = array();
              foreach ($groups_ids as $group_id) {
                if ($group_id != '3:0' && substr($group_id, 0, 1) == '3') $gggr[] = '"'.$groups[$group_id].'"';
              }
              $notices[] = '<span class="label label-warning">Подозрительный.'.(count($gggr) > 0 ? ' Ярлык '.implode(', ', $gggr) : '').'</span>';
            }
            foreach ($targets as $target) {
              if (strpos($pieces[3], $target[2]) !== false) {
                $notices[] = '<span class="label label-info">Найдена цель "'.$target[0].'"</span>';
                $row_style = ' class="info"';
              }
            }
            $HTML .= '<tr'.$row_style.'>
              <td>'.date('d.m.Y H:i:s', $pieces[0]).'</td>
              <td>'.$pieces[1].'<br /><a href="https://www.nic.ru/whois/?query='.$pieces[1].'" target="_blank" rel="tooltip" title="IP whois"><i class="icon-search"></i></a>&nbsp;<a href="#block_ip" rel="tooltip" title="Заблокировать IP" data-toggle="modal" onclick="initBlockWindow(\''.$pieces[1].'\');"><i class="icon-ban-circle"></i></a>&nbsp;<a href="#danger_ip" rel="tooltip" title=\'Добавить в "опасные"\' data-toggle="modal" onclick="initDangerWindow(\''.$pieces[1].'\');"><i class="icon-warning-sign"></i></a>&nbsp;<a href="#suspic_ip" rel="tooltip" title=\'Добавить в "подозрительные"\' data-toggle="modal" onclick="initSuspicWindow(\''.$pieces[1].'\');"><i class="icon-eye-open"></i></a></td>
              <td>'.(isset($geodata['country']) ? $geodata['country'].'&nbsp;<a href="admin_panel.php?action=online&subaction=block_country&c='.$geodata['country'].'" rel="tooltip" title="Заблокировать страну"><i class="icon-ban-circle"></i></a>' : '??').' '.(isset($geodata['city']) ? $geodata['city'].'&nbsp;<a href="#block_city" rel="tooltip" title="Заблокировать город" data-toggle="modal" onclick="initBlockWindowCity(\''.$geodata['city'].'\');"><i class="icon-ban-circle"></i></a>' : '??').'</td>
              <td>'.(trim($pieces[4]) == '' ? '&nbsp;' : '<a href="'.$pieces[4].'" target="_blank">'.$pieces[4].'</a>').'</td>
              <td>'.(trim($pieces[3]) == '' ? '&nbsp;' : $pieces[3]).'</td>
              <td>'.(count($notices) > 0 ? implode('<br />', $notices) : '<span class="label label-success">OK</span>').'</td>
            </tr>';
          }
        }
        if ($records_per_page < count($save_data)) {
          $HTML .= '<div class="pagination pagination-centered"><ul>';
          for ($i=1;$i<=ceil(count($save_data)/$records_per_page);$i++) {
            if ($i != $current_page) $HTML .= '<li><a href="admin_panel.php?action=online&page='.$i.'">'.$i.'</a></li>'; else $HTML .= '<li class="active"><span><strong>'.$i.'</strong></span></li>';
          }
          $HTML .= '</ul></div>';
        }
      } else $HTML .= '<div class="alert alert-error">Данные отсутствуют.</div>';
      $HTML .= '</tbody></table>';
    } else $HTML .= '<div class="alert alert-error">Данные отсутствуют.</div>';
    $HTML .= '<div id="block_ip" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 id="myModalLabel1">Заблокировать IP</h4>
      </div>
      <div class="modal-body">
        <form action="admin_panel.php?action=online&subaction=block_ip" method="post">
          <input type="hidden" name="ip" value="" id="ipvalue1" />
          <label>Ярлык</label>
          <select name="groupid" class="span12">';
    $blocks = @unserialize(file_get_contents(dirname(__FILE__).'/block.txt'));
    if (!is_array($blocks)) $blocks = array(array('group' => 'default'));
    foreach ($blocks as $key => $block) {
      $HTML .= '<option value="'.$key.'">'.($block['group'] == 'default' ? 'Без ярлыка' : $block['group']).'</option>';
    }
    $HTML .= '</select>
      </div>
      <div class="modal-footer">
          <a class="btn" data-dismiss="modal" aria-hidden="true">Отмена</a>
          <button class="btn btn-primary" type="submit">Записать</button>
        </form>
      </div>
    </div>
<script>
function initBlockWindow(ip) {
  $(\'#ipvalue1\').val(ip);
  $(\'#myModalLabel1\').text(\'Заблокировать IP "\' + ip + \'"\');
};
</script>';
    $HTML .= '<div id="danger_ip" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 id="myModalLabel2">Добавить в "опасные" IP</h4>
      </div>
      <div class="modal-body">
        <form action="admin_panel.php?action=online&subaction=danger_ip" method="post">
          <input type="hidden" name="ip" value="" id="ipvalue2" />
          <label>Ярлык</label>
          <select name="groupid" class="span12">';
    $blocks = @unserialize(file_get_contents(dirname(__FILE__).'/danger.txt'));
    if (!is_array($blocks)) $blocks = array(array('group' => 'default'));
    foreach ($blocks as $key => $block) {
      $HTML .= '<option value="'.$key.'">'.($block['group'] == 'default' ? 'Без ярлыка' : $block['group']).'</option>';
    }
    $HTML .= '</select>
      </div>
      <div class="modal-footer">
          <a class="btn" data-dismiss="modal" aria-hidden="true">Отмена</a>
          <button class="btn btn-primary" type="submit">Записать</button>
        </form>
      </div>
    </div>
<script>
function initDangerWindow(ip) {
  $(\'#ipvalue2\').val(ip);
  $(\'#myModalLabel2\').text(\'Добавить в "опасные" IP "\' + ip + \'"\');
};
</script>';
    $HTML .= '<div id="suspic_ip" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3" aria-hidden="true">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 id="myModalLabel3">Добавить в "подозрительные" IP</h4>
      </div>
      <div class="modal-body">
        <form action="admin_panel.php?action=online&subaction=suspic_ip" method="post">
          <input type="hidden" name="ip" value="" id="ipvalue3" />
          <label>Ярлык</label>
          <select name="groupid" class="span12">';
    $blocks = @unserialize(file_get_contents(dirname(__FILE__).'/suspic.txt'));
    if (!is_array($blocks)) $blocks = array(array('group' => 'default'));
    foreach ($blocks as $key => $block) {
      $HTML .= '<option value="'.$key.'">'.($block['group'] == 'default' ? 'Без ярлыка' : $block['group']).'</option>';
    }
    $HTML .= '</select>
      </div>
      <div class="modal-footer">
          <a class="btn" data-dismiss="modal" aria-hidden="true">Отмена</a>
          <button class="btn btn-primary" type="submit">Записать</button>
        </form>
      </div>
    </div>
<script>
function initSuspicWindow(ip) {
  $(\'#ipvalue3\').val(ip);
  $(\'#myModalLabel3\').text(\'Добавить в "подозрительные" IP "\' + ip + \'"\');
};
</script>';
$HTML .= '<div id="block_city" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel4" aria-hidden="true">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 id="myModalLabel4">Заблокировать город</h4>
      </div>
      <div class="modal-body">
        <form action="admin_panel.php?action=online&subaction=block_city" method="post">
          <input type="hidden" name="c" value="" id="cvalue1" />
          <label>Ярлык</label>
          <select name="groupid" class="span12">';
    $blocks = @unserialize(file_get_contents(dirname(__FILE__).'/block.txt'));
    if (!is_array($blocks)) $blocks = array(array('group' => 'default'));
    foreach ($blocks as $key => $block) {
      $HTML .= '<option value="'.$key.'">'.($block['group'] == 'default' ? 'Без ярлыка' : $block['group']).'</option>';
    }
    $HTML .= '</select>
      </div>
      <div class="modal-footer">
          <a class="btn" data-dismiss="modal" aria-hidden="true">Отмена</a>
          <button class="btn btn-primary" type="submit">Записать</button>
        </form>
      </div>
    </div>
<script>
function initBlockWindowCity(c) {
  $(\'#cvalue1\').val(c);
  $(\'#myModalLabel4\').text(\'Заблокировать город "\' + c + \'"\');
};
</script>';
    if ($current_page == 1) {
      $HTML .= '<audio id="beep_sound">
  <source src="sound/beep.mp3"></source>
  <source src="sound/beep.ogg"></source>
</audio>
<script>
var last_time = '.(int)$last_time.';
(function poll() {
$.ajax({
  url: "get_online_data.php",
  type: "POST",
  data: {
    lt: last_time,
    ft: '.$_SESSION['filter_target'].',
    fg: '.$_SESSION['filter_group'].',
  },
  success: function(data) {
    if (data.length > 0) {
      last_time = data[0][0];
      for (i=0;i<data.length;i++) {
        $("#online_table").prepend(data[i][1]);
      }
      $("#beep_sound")[0].play();
    }
  },
  dataType: "json",
  complete: poll,
  timeout: 30000
});
})();
</script>';
    }
  } elseif (isset($_GET['action']) && $_GET['action'] == 'main') {
################################################################################################################################
# Страница основных настроек
################################################################################################################################
    if (isset($_POST['action']) && $_POST['action'] == 'save_main') { # Сохранение основных настроек
      $config2 = $config;
      $fin_config = "<?php\r\n";
      if (!isset($_POST['save_data_source'])) $_POST['save_data_source'] = 0;
      foreach($config2 as $name => $value) {
        if (isset($_POST[$name])) {
          ## Если есть данные	
      		if ($name == 'redirect_from_urls') {
            $fin_config .= "\$config['redirect_from_urls'] = '".implode('<|||>', explode("\n", strtolower(preg_replace('#\r#Uis', '', $_POST['redirect_from_urls']))))."';\r\n";
      		} elseif ($name == 'save_data_source') {
            if (is_array($_POST['save_data_source'])) {
              $fin_config .= "\$config['save_data_source'] = ".set_bitflag($_POST['save_data_source']).";\r\n";
            } else $fin_config .= "\$config['save_data_source'] = 0;\r\n";
      		} elseif (preg_match('#^TRUE$|^FALSE$|^[0-9]+$#Uis',$_POST[$name])) {
            $fin_config .= "\$config['".$name."'] = ".$_POST[$name].";\r\n";
      		} else {
            $val = str_replace('\\','\\\\',$_POST[$name]);
            $val = str_replace('\'','\\\'',$val);
            $fin_config .= "\$config['".$name."'] = '".$val."';\r\n";
      		}
        } else {
      	## Если нет данных (оставляем старые)
      		if (gettype($value) == 'boolean' || gettype($value) == 'integer') {
            if ($value === true) $val = 'TRUE';
            elseif ($value === false) $val = 'FALSE';
            $fin_config .= "\$config['".$name."'] = ".$val.";\r\n";
          } else {
            $val = str_replace('\\','\\\\',$value);
            $val = str_replace('\'','\\\'',$val);
            $fin_config .= "\$config['".$name."'] = '".$val."';\r\n";
      		}
        }
      }
      $fin_config .= "\r\n?>";

      $save_config = @fopen( dirname(__FILE__).'/config.php', "w+" );
      $fw = @fwrite($save_config, $fin_config);
      @fclose($save_config);
      if ($fw) {
        $HTML .= '<div class="alert alert-success">Настройки сохранены.</div>';
      } else {
        $HTML .= '<div class="alert alert-error">Настройки не сохранены.</div>';
      }
      include(dirname(__file__).'/config.php');
    }
    
    $tabs = array(
      'Копирка' => array('site','my_domain','redirect','redirect_url','analytics','analytics_code','analytics_place'),
      'Арбитраж' => array('save_data','save_data_source','redirect_from','redirect_from_urls','blocked_action','blocked_site','danger_action','danger_site'),
      'Other' => array('on_cookie','del_links','charset','to_charset', 'debug','cache','maxsizecache','timecache','time2cache','file2cache', 'sape','sape_key'),
    );
    $tabs_html = array();
    
    $HTML .= '<div class="well"><ul class="nav nav-pills" id="ligroups" style="margin-bottom:0;">';
    $ii = 0;
    foreach ($tabs as $key => $tab) {
      $HTML .= '<li'.($ii == 0 ? ' class="active"' : '').'><a href="#tab'.$ii.'" data-toggle="tab" id="agroup'.$ii.'">'.$key.'</a></li>';
      $tabs_html[$ii] = '';
      $ii++;
    }
    $HTML .= '</ul></div>';
    $HTML .= '<form action="" method="POST">';
    $HTML .= '<div class="tab-content">';
    
    foreach ($config as $name => $value) {
      if ($name == 'ver') continue;
      $ii = 0;
      foreach ($tabs as $tab) {
        if (in_array($name, $tab)) {
          $echo = &$tabs_html[$ii];
          break;
        }
        $ii++;
      }
      $echo .= '<label>'.$lang[$name].'</label>';
      $on = '';
      $off = '';
      if ($name == 'redirect') {
        $echo .= '<label class="radio"><input type="radio" name="redirect" value="no"'.($config['redirect'] == 'no' ? 'checked="checked"' : '').'> Выключить</label>
    					   	<label class="radio"><input type="radio" name="redirect" value="all"'.($config['redirect'] == 'all' ? 'checked="checked"' : '').'> Включить</label>
                  ';
      } elseif ($name == 'danger_action') {
        $echo .= '<label class="radio"><input type="radio" name="danger_action" value="default"'.($config['danger_action'] == 'default' ? 'checked="checked"' : '').'> Копировать сайт по умолчанию</label>
    					   	<label class="radio"><input type="radio" name="danger_action" value="file"'.($config['danger_action'] == 'file' ? 'checked="checked"' : '').'> Показывать конкретный файл</label>
                  <label class="radio"><input type="radio" name="danger_action" value="site"'.($config['danger_action'] == 'site' ? 'checked="checked"' : '').'> Копировать альтернативный сайт</label>';
      } elseif ($name == 'blocked_action') {
        $echo .= '<label class="radio"><input type="radio" name="blocked_action" value="default"'.($config['blocked_action'] == 'default' ? 'checked="checked"' : '').'> Копировать сайт по умолчанию</label>
                  <label class="radio"><input type="radio" name="blocked_action" value="site"'.($config['blocked_action'] == 'site' ? 'checked="checked"' : '').'> Копировать альтернативный сайт</label>';
      } elseif ($name == 'redirect_from') {
        $echo .= '<label class="radio"><input type="radio" name="redirect_from" value="all"'.($config['redirect_from'] == 'all' ? 'checked="checked"' : '').'> Со всего сайта</label>
                  <label class="radio"><input type="radio" name="redirect_from" value="url"'.($config['redirect_from'] == 'url' ? 'checked="checked"' : '').'> Только с указанных адресов</label>';
      } elseif ($name == 'redirect_from_urls') {
        $echo .= '<textarea rows="5" name="redirect_from_urls" class="input-xxlarge">'.@str_replace("<|||>", "\r\n", $config['redirect_from_urls']).'</textarea><br />';
      } elseif ($name == 'analytics_code') {
        $echo .= '<textarea rows="5" name="analytics_code" class="input-xxlarge">'.$config['analytics_code'].'</textarea><br />';
      } elseif ($name == 'analytics_place') {
        $echo .= '<label class="radio"><input type="radio" name="analytics_place" value="head"'.($config['analytics_place'] == 'head' ? 'checked="checked"' : '').'> Перед "&lt;/head&gt;"</label>
                  <label class="radio"><input type="radio" name="analytics_place" value="body"'.($config['analytics_place'] == 'body' ? 'checked="checked"' : '').'> После "&lt;body&gt;"</label>';
      } elseif ($name == 'save_data_source') {
        $echo .= '<label class="checkbox"><input type="checkbox" name="save_data_source[]" value="1"'.(is_bitflag_set((int)$config['save_data_source'], SDS_BLOCKED) ? 'checked="checked"' : '').'> Заблокированных</label>
                  <label class="checkbox"><input type="checkbox" name="save_data_source[]" value="2"'.(is_bitflag_set((int)$config['save_data_source'], SDS_DANGER) ? 'checked="checked"' : '').'> Опасных</label>
                  <label class="checkbox"><input type="checkbox" name="save_data_source[]" value="4"'.(is_bitflag_set((int)$config['save_data_source'], SDS_SUSPIC) ? 'checked="checked"' : '').'> Подозрительных</label>
                  <label class="checkbox"><input type="checkbox" name="save_data_source[]" value="8"'.(is_bitflag_set((int)$config['save_data_source'], SDS_OTHER) ? 'checked="checked"' : '').'> Всех остальных</label>';
      } elseif ($value === FALSE or $value === TRUE) {
        if ($value === TRUE) $on = ' checked'; else $off = ' checked';
        $echo .= '<label class="radio"><input type="radio" name="'.$name.'" value="TRUE"'.$on.'><font style="color: green;">Вкл.</font></label> <label class="radio"><input type="radio" name="'.$name.'" value="FALSE"'.$off.'><font style="color: red;">Выкл.</font></label>';
      } else {
        $echo .= '<input type="text" name="'.$name.'" value="'.$value.'" class="input-xxlarge" /><br />';
      }
      $echo .= '<br />';
    }
    
    foreach ($tabs_html as $key => $value) {
      $HTML .= '<div class="tab-pane'.($key == 0 ? ' active' : '').'" id="tab'.$key.'">'.$value.'</div>';
    }
    $HTML .= '<br />
  <input type="hidden" name="action" value="save_main" />
  <input type="submit" value="Сохранить" class="btn btn-primary" />
  </form></div>';
  } elseif (isset($_POST['action']) && $_POST['action'] == 'save_replace') { # Сохранение замены кода
    foreach ($_POST as $name => $value) {
      if (!preg_match('#search#Uis', $name) or empty($value)) continue;
      $e = explode('_', $name);
      if (!empty($_POST['delete_'.$e[1]])) continue;
      if (!empty($_POST['reg_'.$e[1]])) $reg_on = '<|||>REG_ON'; else $reg_on = '';
      $echo .= "<replace>".$value."<|||>".($_POST['replace_'.$e[1]].$reg_on)."</replace>\r\n\r\n";
      unset($reg_on);
    }
    if (!empty($echo)) {
   		$save = @fopen( dirname(__FILE__).'/replace.txt', "w+" );
   		$fw = @fwrite($save, $echo);
   		@fclose($save);
   		if ($fw) {
        $HTML .= '<div class="alert alert-success">Настройки сохранены.</div>';
      } else {
        $HTML .= '<div class="alert alert-error">Настройки не сохранены.</div>';
      }
    } else {
      $HTML .= '<div class="alert alert-error">Настройки не сохранены.</div>';
    }
  } elseif (isset($_GET['action']) && $_GET['action'] == 'replace') { # Страница замены кода
    $replace = @file_get_contents(dirname(__FILE__).'/replace.txt');
    if ($replace === false) die('Невозможно открыть replace.txt! Быть может, Вы его удалили?');
    preg_match_all('#<replace>(.*)</replace>#Uis', $replace, $preg);
    $n = count($preg[1]);
    for ($i=0;$i<$n;$i++) {
      $e = explode('<|||>', $preg[1][$i]);
      if (isset($e[2]) && $e[2] == 'REG_ON') $ch = 'checked'; else $ch = '';
      $echo .= '<tr>
<td class="td"><textarea name="search_'.$i.'" class="textarea">'.$e[0].'</textarea></td>
<td class="td"><textarea name="replace_'.$i.'" class="textarea">'.$e[1].'</textarea></td>
<td class="td"><center><input type="checkbox" name="reg_'.$i.'" '.$ch.'><center></td>
<td class="td"><center><input type="checkbox" name="delete_'.$i.'"><center></td>
<tr>';
      unset($ch);
    }

    $HTML .= '<script>
var countOfFields = '.$n.'; // Текущее число полей
var ID = '.$n.'; // Уникальное значение для атрибута name
function addField() {
  // Увеличиваем ID
  ID++;
  document.getElementById("parentId").innerHTML += "<tr><td class=\"td\"><textarea name=\"search_"+ID+"\" class=\"textarea\"></textarea></td><td class=\"td\"><textarea name=\"replace_"+ID+"\" class=\"textarea\"></textarea></td><td class=\"td\"><center><input type=\"checkbox\" name=\"reg_"+ID+"\"><center></td><td class=\"td\"><center><input type=\"checkbox\" name=\"delete_"+ID+"\"><center></td><tr>";
  // Возвращаем false, чтобы не было перехода по сслыке
  return false;
}
</script>

<center>
<form action="" method="POST">
<div>
<table width="80%" id="parentId">
<tr>
<td class="td" width="50%"><center><b>Что менять</b></center></td>
<td class="td" width="50%"><center><b>На что менять</b></center></td>
<td class="td" width="50px"><center>Регулярки</center></td
<td class="td" width="50px"><center>Delete</center></td><tr>
    '.$echo.'
</table>
<input type="button" onclick="return addField()" class="btn" value="Добавить поле" />
<input name="action" value="save_replace" type="hidden">
<input type="submit" value="Сохранить" class="btn btn-primary" onclick="return confirm (\'Вы уверены?\')">
</div>
</form>
</center>';
  } elseif (isset($_GET['action']) && $_GET['action'] == 'clean') {
################################################################################################################################
# Очистка кеша
################################################################################################################################
    $files = scandir(dirname(__FILE__).'/cache/');
    foreach ($files as $name => $value) {
      if (strlen($value) !== 32) continue;
      $if = @unlink(dirname(__FILE__).'/cache/'.$value);
      if (!$if) die ('Невозможно удалить файлы! (Нет прав?)');
      $d++;
    }
    $HTML .= '<div class="alert alert-success">Кеш очищен. Всего удалено файлов кеша: '.(intval($d)).'</div>';
  }
} else {
  $HTML .= '<div class="alert alert-error">ERROR!</div>';
}
$HTML .= '</div></div></div></body></html>';
echo $HTML;
?>