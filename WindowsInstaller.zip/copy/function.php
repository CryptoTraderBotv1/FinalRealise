<?php
function block($data = null) {
	$block0 = @unserialize(file_get_contents(dirname(__FILE__) . '/block.txt'));
  $block = array('ip' => array(), 'host_referer' => array(), 'referer' => array(), 'diapazon' => array(), 'country_block' => array(), 'city_block' => array());
  foreach ($block0 as $key => $value) {
    $block = array_merge_recursive($block, $value);
  }
	if ($data == null) {
  	$ip = $_SERVER['REMOTE_ADDR'];
  	if ( isset($_SERVER['MOD_REFERER']) ) {
  		$referer = $_SERVER['MOD_REFERER'];
  		$host_referer = parse_url($referer);
  		$host_referer = strtolower($host_referer['host']);
  	} else {
  		$referer = false;
  		$host_referer = false;
  	}
  } else {
    $ip = '';
    $referer = '';
    $host_referer = '';
    if (isset($data[0])) $ip = $data[0];
    if (isset($data[1])) {
      $referer = $data[1];
  		$host_referer = parse_url($referer);
      if (isset($host_referer['host']))	$host_referer = strtolower($host_referer['host']); else $host_referer = '';
  	}
  }
  
  if (count($block['ip']) > 0 && $ip != '') {
		foreach ($block['ip'] as $bip) {
			if (trim($bip) != '' && preg_match('#^'.preg_quote($bip, '#').'#Uis', $ip)) {
				return true;
			}
		}
	}
  
  if (count($block['host_referer']) > 0 && $host_referer != '') {
		if (in_array($host_referer, $block['host_referer'])) {
			return true;
		}
	}
	
	if (count($block['referer']) > 0 && $referer != '') {
		if (in_array($referer, $block['referer'])) {
			return true;
		}
	}
  
  if (count($block['diapazon']) > 0) {
		foreach ($block['diapazon'] as $bdiapazon) {
      if (trim($bdiapazon) != '') {
        $ips = explode('-', $bdiapazon);
        if (count($ips) == 2 && ip2int($ip) >= ip2int(trim($ips[0])) && ip2int($ip) <= ip2int(trim($ips[1]))) {
    			return true;
    		}
      }
		}
	}
  
  require_once('geo.php');
  $geo = new Geo(array('ip' => $ip, 'charset' => 'utf-8'));
  $geodata = $geo->get_value();
  
  foreach ($block0 as $block) {
    if (isset($geodata['country'])) {
    	foreach ($block['country'] as $kkk => $vvv) {
    		$block['country'][$kkk] = strtolower($vvv);
    	}
      if (isset($block['country']) && count($block['country']) > 0) {
        if ($block['country_block'] == '1' && in_array(strtolower($geodata['country']), $block['country'])) return true;
        if ($block['country_block'] == '2' && !in_array(strtolower($geodata['country']), $block['country'])) return true;
      }
    }
    
    if (isset($geodata['city'])) {
    	foreach ($block['city'] as $kkk => $vvv) {
    		$block['city'][$kkk] = strtolower($vvv);
    	}
      if (isset($block['city']) && count($block['city']) > 0) {
        if ($block['city_block'] == '1' && in_array(strtolower($geodata['city']), $block['city'])) return true;
        if ($block['city_block'] == '2' && !in_array(strtolower($geodata['city']), $block['city'])) return true;
      }
    }
  }
  
	return false;
}

function get_groups_ids($data = null) {
  $result = array();
	$block0 = @unserialize(file_get_contents(dirname(__FILE__) . '/block.txt'));
  foreach ($block0 as $key => $block) {
  	if ($data == null) {
    	$ip = $_SERVER['REMOTE_ADDR'];
    	if ( isset($_SERVER['MOD_REFERER']) ) {
    		$referer = $_SERVER['MOD_REFERER'];
    		$host_referer = parse_url($referer);
    		$host_referer = strtolower($host_referer['host']);
    	} else {
    		$referer = false;
    		$host_referer = false;
    	}
    } else {
      $ip = '';
      $referer = '';
      $host_referer = '';
      if (isset($data[0])) $ip = $data[0];
      if (isset($data[1])) {
        $referer = $data[1];
    		$host_referer = parse_url($referer);
        if (isset($host_referer['host']))	$host_referer = strtolower($host_referer['host']); else $host_referer = '';
    	}
    }
    if ( count($block['ip']) > 0 ) {
  		foreach ( $block['ip'] as $bip ) {
  			if (trim($bip) != '' && preg_match('#^' . preg_quote($bip, '#') . '#Uis', $ip) ) {
  				$result[] = '1:'.$key;
  			}
  		}
  	}
  	
  	if ( count($block['host_referer']) > 0 and $host_referer != false ) {
  		if ( in_array($host_referer, $block['host_referer']) ) {
  			$result[] = '1:'.$key;
  		}
  	}
  	
  	if ( count($block['referer']) > 0 and $referer != false ) {
  		if ( in_array($referer, $block['referer']) ) {
  			$result[] = '1:'.$key;
  		}
  	}
    
    if ( count($block['diapazon']) > 0 ) {
  		foreach ( $block['diapazon'] as $bdiapazon ) {
        if (trim($bdiapazon) != '') {
          $ips = explode('-', $bdiapazon);
          if (count($ips) == 2 && ip2int($ip) >= ip2int(trim($ips[0])) && ip2int($ip) <= ip2int(trim($ips[1]))) {
      			$result[] = '1:'.$key;
      		}
        }
  		}
  	}
    
    require_once('geo.php');
    $geo = new Geo(array('ip' => $ip, 'charset' => 'utf-8'));
    $geodata = $geo->get_value();
    
    if (isset($geodata['country'])) {
      if (isset($block['country'])) {
        if ($block['country_block'] == '1' && in_array($geodata['country'], $block['country'])) $result[] = '1:'.$key;
        if ($block['country_block'] == '2' && !in_array($geodata['country'], $block['country'])) $result[] = '1:'.$key;
      }
    }
    
    if (isset($geodata['city'])) {
      if (isset($block['city'])) {
        if ($block['city_block'] == '1' && in_array($geodata['city'], $block['city'])) $result[] = '1:'.$key;
        if ($block['city_block'] == '2' && !in_array($geodata['city'], $block['city'])) $result[] = '1:'.$key;
      }
    }
  }
  
  $block0 = @unserialize(file_get_contents(dirname(__FILE__) . '/danger.txt'));
  foreach ($block0 as $key => $block) {
  	if ($data == null) {
    	$ip = $_SERVER['REMOTE_ADDR'];
    	if ( isset($_SERVER['MOD_REFERER']) ) {
    		$referer = $_SERVER['MOD_REFERER'];
    		$host_referer = parse_url($referer);
    		$host_referer = strtolower($host_referer['host']);
    	} else {
    		$referer = false;
    		$host_referer = false;
    	}
    } else {
      $ip = '';
      $referer = '';
      $host_referer = '';
      if (isset($data[0])) $ip = $data[0];
      if (isset($data[1])) {
        $referer = $data[1];
    		$host_referer = parse_url($referer);
        if (isset($host_referer['host']))	$host_referer = strtolower($host_referer['host']); else $host_referer = '';
    	}
    }
    if ( count($block['ip']) > 0 ) {
  		foreach ( $block['ip'] as $bip ) {
  			if (trim($bip) != '' && preg_match('#^' . preg_quote($bip, '#') . '#Uis', $ip)) {
  				$result[] = '2:'.$key;
  			}
  		}
  	}
  	
  	if ( count($block['host_referer']) > 0 and $host_referer != false ) {
  		if ( in_array($host_referer, $block['host_referer']) ) {
  			$result[] = '2:'.$key;
  		}
  	}
  	
  	if ( count($block['referer']) > 0 and $referer != false ) {
  		if ( in_array($referer, $block['referer']) ) {
  			$result[] = '2:'.$key;
  		}
  	}
    
    if ( count($block['diapazon']) > 0 ) {
  		foreach ( $block['diapazon'] as $bdiapazon ) {
        if (trim($bdiapazon) != '') {
          $ips = explode('-', $bdiapazon);
          if (count($ips) == 2 && ip2int($ip) >= ip2int(trim($ips[0])) && ip2int($ip) <= ip2int(trim($ips[1]))) {
      			$result[] = '2:'.$key;
      		}
        }
  		}
  	}
  }
  
  $block0 = @unserialize(file_get_contents(dirname(__FILE__) . '/suspic.txt'));
  foreach ($block0 as $key => $block) {
  	if ($data == null) {
    	$ip = $_SERVER['REMOTE_ADDR'];
    	if ( isset($_SERVER['MOD_REFERER']) ) {
    		$referer = $_SERVER['MOD_REFERER'];
    		$host_referer = parse_url($referer);
    		$host_referer = strtolower($host_referer['host']);
    	} else {
    		$referer = false;
    		$host_referer = false;
    	}
    } else {
      $ip = '';
      $referer = '';
      $host_referer = '';
      if (isset($data[0])) $ip = $data[0];
      if (isset($data[1])) {
        $referer = $data[1];
    		$host_referer = parse_url($referer);
        if (isset($host_referer['host']))	$host_referer = strtolower($host_referer['host']); else $host_referer = '';
    	}
    }
    if ( count($block['ip']) > 0 ) {
  		foreach ( $block['ip'] as $bip ) {
  			if (trim($bip) != '' && preg_match('#^' . preg_quote($bip, '#') . '#Uis', $ip)) {
  				$result[] = '3:'.$key;
  			}
  		}
  	}
  	
  	if ( count($block['host_referer']) > 0 and $host_referer != false ) {
  		if ( in_array($host_referer, $block['host_referer']) ) {
  			$result[] = '3:'.$key;
  		}
  	}
  	
  	if ( count($block['referer']) > 0 and $referer != false ) {
  		if ( in_array($referer, $block['referer']) ) {
  			$result[] = '3:'.$key;
  		}
  	}
  }
  
	return $result;
}

function danger($data = null) {
	$block0 = @unserialize(file_get_contents(dirname(__FILE__) . '/danger.txt'));
	$block = array('ip' => array(), 'host_referer' => array(), 'referer' => array(), 'diapazon' => array());
  foreach ($block0 as $key => $value) {
    $block = array_merge_recursive($block, $value);
  }
	if ($data == null) {
  	$ip = $_SERVER['REMOTE_ADDR'];
  	if ( isset($_SERVER['MOD_REFERER']) ) {
  		$referer = $_SERVER['MOD_REFERER'];
  		$host_referer = parse_url($referer);
  		$host_referer = strtolower($host_referer['host']);
  	} else {
  		$referer = false;
  		$host_referer = false;
  	}
  } else {
    $ip = '';
    $referer = '';
    $host_referer = '';
    if (isset($data[0])) $ip = $data[0];
    if (isset($data[1])) {
      $referer = $data[1];
  		$host_referer = parse_url($referer);
      if (isset($host_referer['host']))	$host_referer = strtolower($host_referer['host']); else $host_referer = '';
  	}
  }
  if ( count($block['ip']) > 0 ) {
		foreach ( $block['ip'] as $bip ) {
			if (trim($bip) != '' && preg_match('#^' . preg_quote($bip, '#') . '#Uis', $ip)) {
				return true;
			}
		}
	}
	
	if ( count($block['host_referer']) > 0 and $host_referer != false ) {
		if ( in_array($host_referer, $block['host_referer']) ) {
			return true;
		}
	}
	
	if ( count($block['referer']) > 0 and $referer != false ) {
		if ( in_array($referer, $block['referer']) ) {
			return true;
		}
	}
  
  if ( count($block['diapazon']) > 0 ) {
		foreach ( $block['diapazon'] as $bdiapazon ) {
      if (trim($bdiapazon) != '') {
        $ips = explode('-', $bdiapazon);
        if (count($ips) == 2 && ip2int($ip) >= ip2int(trim($ips[0])) && ip2int($ip) <= ip2int(trim($ips[1]))) {
    			return true;
    		}
      }
		}
	}
	return false;
}

function suspicious($data = null) {
	$block0 = @unserialize(file_get_contents(dirname(__FILE__) . '/suspic.txt'));
  $block = array('ip' => array(), 'host_referer' => array(), 'referer' => array());
  foreach ($block0 as $key => $value) {
    $block = array_merge_recursive($block, $value);
  }
	if ($data == null) {
  	$ip = $_SERVER['REMOTE_ADDR'];
  	if ( isset($_SERVER['MOD_REFERER']) ) {
  		$referer = $_SERVER['MOD_REFERER'];
  		$host_referer = parse_url($referer);
  		$host_referer = strtolower($host_referer['host']);
  	} else {
  		$referer = false;
  		$host_referer = false;
  	}
  } else {
    $ip = '';
    $referer = '';
    $host_referer = '';
    if (isset($data[0])) $ip = $data[0];
    if (isset($data[1])) {
      $referer = $data[1];
  		$host_referer = parse_url($referer);
      if (isset($host_referer['host']))	$host_referer = strtolower($host_referer['host']); else $host_referer = '';
  	}
  }
  if ( count($block['ip']) > 0 ) {
		foreach ( $block['ip'] as $bip ) {
			if (trim($bip) != '' && preg_match('#^' . preg_quote($bip, '#') . '#Uis', $ip)) {
				return true;
			}
		}
	}
	
	if ( count($block['host_referer']) > 0 and $host_referer != false ) {
		if ( in_array($host_referer, $block['host_referer']) ) {
			return true;
		}
	}
	
	if ( count($block['referer']) > 0 and $referer != false ) {
		if ( in_array($referer, $block['referer']) ) {
			return true;
		}
	}
	return false;
}

function ip2int($ip) {
  $a = explode(".", trim($ip));
  return (int)trim($a[0])*256*256*256 + (int)trim($a[1])*256*256 + (int)trim($a[2])*256 + (int)trim($a[3]);
}

function set_bitflag($flags) {
  $val = 0;
  foreach($flags as $flag) $val = $val | $flag;
  return $val;
}

function is_bitflag_set($val, $flag) {
  return (($val & $flag) === $flag);
}

## Переводим текст через гугл транслейт
function translate ($text,$lang1,$lang2) {
if ( empty($text) or empty($lang1) or empty($lang2) ) return false;

$text = iconv('cp1251','utf-8',$text);

$lang1 = strtolower($lang1);
$lang2 = strtolower($lang2);


$url = 'http://ajax.googleapis.com/ajax/services/language/translate';

$post = array (
'v' => '1.0',
'q' => $text,
'langpair' => $lang1.'|'.$lang2,
'format' => 'html',
);



    $data = curl_init($url);
	curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($data, CURLOPT_REFERER, 'http://google.ru');
    curl_setopt($data, CURLOPT_POST, '1');
    curl_setopt($data, CURLOPT_POSTFIELDS, $post);
    $code .= curl_exec($data);


if ( !$code ) return false;

$translate = json_decode($code,true);
$translate = strval($translate['responseData']['translatedText']);


if ( empty($translate)) return false;


return $translate;

}




## Накладываем водяной знак.

function watermark ($code,$format) {
global $config;
if ( empty($code) or empty($format) or !file_exists(dirname(__FILE__).'/datafiles/'.$config['watermark_image']) ) return false;


$w = imagecreatefrompng(dirname(__FILE__).'/datafiles/'.$config['watermark_image']);
$image = imagecreatefromstring($code);

$w_w = imagesx($w);
$w_h = imagesy($w);

$i_w = imagesx($image);
$i_h = imagesy($image);


$ex = @explode(';',$config['watermarkxy']);

if ( !empty($ex[0]) ) {
$width = round((($i_w-$w_w)/100)*$ex[0],0);
} else {
$width = 0;
}

if ( !empty($ex[1]) ) {
$height = round((($i_h-$w_h)/100)*$ex[1],0);
} else {
$height = 0;
}

imagecopy ($image,
$w,
$width,
$height,
0,
0,
$w_w,
$w_h);


ob_start();
if ( $format == 'jpeg' or $format == 'jpg' ) {
imagejpeg ($image,false,100);
} elseif ( $format == 'png' ) {
imagepng ($image);
} elseif ( $format == 'gif' ) {
imagegif ($image);
}
$fin = ob_get_clean();


imagedestroy ($image);
imagedestroy ($w);


return $fin;
}



## Определяем, накладывать ли водяной знак на изображение, или нет.

function is_watermark ($name) {
global $config;
if ( !$config['watermark'] or empty($name) ) return false;


$extension = strtolower(array_pop(explode('.',$name)));
if (( $extension == 'png' or $extension == 'jpg' or $extension == 'jpeg' or $extension == 'gif' ) and preg_match('#'.$config['watermarkna'].'#Ui',$name) ) return true;

return false;

}


## Проверяем кеш на существование и актуальность

function ext_cache ($name) {
global $config;
$md5 = md5($name);
if ( !$config['cache'] or empty($name) or !file_exists(dirname(__FILE__).'/cache/'.$md5) ) return false;

$config['cache'] = file_get_contents(dirname(__FILE__).'/cache/'.$md5);
preg_match('#\{time: (.*)\}#Ui',$config['cache'],$time);

if ( $time[1] < time() ) return false;

return true;
}




## Создаем кеш

function save_cache ($name,$code,$headers=false) {
global $config;
if ( $config['cache'] !== true or empty($code) or empty($name) or strlen($code) > $config['maxsizecache'] ) return false;
$md5 = md5($name);

if ( cache2($name) ) {
$time = time()+$config['time2cache'];
} else {
$time = time()+$config['timecache'];
}

$f = fopen(dirname(__FILE__).'/cache/'.$md5,'w+'); if ( !$f ) return false;
$if = fwrite($f,'{time: '.$time.'}{headers: '.$headers.'}'.$code);
fclose($f);

//@chmod(dirname(__FILE__).'/cache/'.$md5,'7777');

if ( !$if ) return false;


return true;
}




## Грузим кеш

function load_cache ($name) {
global $config,$sape;
if ( !$config['cache'] or empty($name) ) return false;
$md5 = md5($name);

$code = @file_get_contents(dirname(__FILE__).'/cache/'.$md5);
if ( !$code ) return false;
preg_match('#\{headers: (.*)\}#Uis',$code,$headers);

$arr_h = @explode('|||',$headers[1]);

$code = preg_replace('#\{(time|headers):(.*)\}#Uis',null,$code);
return array('code'=>$code,'headers'=>$arr_h);
}



## Для второго кеша или нет

function cache2 ($file) {
global $config;
$extension = strtolower(array_pop(explode('.',$file)));
if ( empty($extension) ) return false;

if (preg_match('#'.$extension.'#Uis',strtolower($config['file2cache'])) ) return true;


return false;
}



## 404 ошибка

function error404 () {	
header("HTTP/1.0 404 Not Found");
header("Status: 404 Not Found");
echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
</body></html>';
die();
}



## Определение Content Type

    function get_mimetype($file) {

        $ct['htm'] = 'text/html';
        $ct['html'] = 'text/html';
        $ct['txt'] = 'text/plain';
        $ct['asc'] = 'text/plain';
        $ct['bmp'] = 'image/bmp';
        $ct['gif'] = 'image/gif';
        $ct['jpeg'] = 'image/jpeg';
        $ct['jpg'] = 'image/jpeg';
        $ct['jpe'] = 'image/jpeg';
        $ct['png'] = 'image/png';
        $ct['ico'] = 'image/vnd.microsoft.icon';
        $ct['mpeg'] = 'video/mpeg';
        $ct['mpg'] = 'video/mpeg';
        $ct['mpe'] = 'video/mpeg';
        $ct['qt'] = 'video/quicktime';
        $ct['mov'] = 'video/quicktime';
        $ct['avi']  = 'video/x-msvideo';
        $ct['wmv'] = 'video/x-ms-wmv';
        $ct['mp2'] = 'audio/mpeg';
        $ct['mp3'] = 'audio/mpeg';
        $ct['rm'] = 'audio/x-pn-realaudio';
        $ct['ram'] = 'audio/x-pn-realaudio';
        $ct['rpm'] = 'audio/x-pn-realaudio-plugin';
        $ct['ra'] = 'audio/x-realaudio';
        $ct['wav'] = 'audio/x-wav';
        $ct['css'] = 'text/css';
        $ct['zip'] = 'application/zip';
        $ct['pdf'] = 'application/pdf';
        $ct['doc'] = 'application/msword';
        $ct['bin'] = 'application/octet-stream';
        $ct['exe'] = 'application/octet-stream';
        $ct['class']= 'application/octet-stream';
        $ct['dll'] = 'application/octet-stream';
        $ct['xls'] = 'application/vnd.ms-excel';
        $ct['ppt'] = 'application/vnd.ms-powerpoint';
        $ct['wbxml']= 'application/vnd.wap.wbxml';
        $ct['wmlc'] = 'application/vnd.wap.wmlc';
        $ct['wmlsc']= 'application/vnd.wap.wmlscriptc';
        $ct['dvi'] = 'application/x-dvi';
        $ct['spl'] = 'application/x-futuresplash';
        $ct['gtar'] = 'application/x-gtar';
        $ct['gzip'] = 'application/x-gzip';
        $ct['js'] = 'application/x-javascript';
        $ct['swf'] = 'application/x-shockwave-flash';
        $ct['tar'] = 'application/x-tar';
        $ct['xhtml']= 'application/xhtml+xml';
        $ct['au'] = 'audio/basic';
        $ct['snd'] = 'audio/basic';
        $ct['midi'] = 'audio/midi';
        $ct['mid'] = 'audio/midi';
        $ct['m3u'] = 'audio/x-mpegurl';
        $ct['tiff'] = 'image/tiff';
        $ct['tif'] = 'image/tiff';
        $ct['rtf'] = 'text/rtf';
        $ct['wml'] = 'text/vnd.wap.wml';
        $ct['wmls'] = 'text/vnd.wap.wmlscript';
        $ct['xsl'] = 'text/xml';
        $ct['xml'] = 'text/xml';

        $extension = array_pop(explode('.',$file));

        if (!$type = $ct[strtolower($extension)]) $type = 'text/html';

        return $type;
    }

?>