<?php
if (isset($_POST['lt'])) {
  $time = time();
  require_once('function.php');
  require_once('geo.php');
  $targets = @unserialize(file_get_contents(dirname(__FILE__).'/targets.txt'));
  $block = @unserialize(file_get_contents(dirname(__FILE__).'/block.txt'));
  $groups = array();
  foreach ($block as $key => $value) {
    if ($value['group'] != 'default') $groups['1:'.$key] = $value['group'];
  }
  $danger = @unserialize(file_get_contents(dirname(__FILE__).'/danger.txt'));
  foreach ($danger as $key => $value) {
    if ($value['group'] != 'default') $groups['2:'.$key] = $value['group'];
  }
  $suspic = @unserialize(file_get_contents(dirname(__FILE__).'/suspic.txt'));
  foreach ($suspic as $key => $value) {
    if ($value['group'] != 'default') $groups['3:'.$key] = $value['group'];
  }
  while ((time() - $time) < 30) {
    $save_data0 = file(dirname(__FILE__).'/save_data.txt');
    $save_data0 = array_reverse($save_data0);
    $save_data = array();
    foreach ($save_data0 as $key => $line) {
      if (trim($line) != '') {
        $pieces = explode(';', $line);
        if ((int)$pieces[0] > (int)$_POST['lt']) $save_data[] = $pieces;
      }
    }
    $new = array();
    foreach ($save_data as $key => $pieces) {
      if (isset($_POST['ft']) && $_POST['ft'] != -1) {
        if (strpos($pieces[3], $targets[$_POST['ft']][2]) === false) continue;
      }
      if (isset($_POST['fg']) && $_POST['fg'] != -1) {
        $groups_ids = get_groups_ids(array($pieces[1], $pieces[2]));
        if (!in_array($_POST['fg'], $groups_ids)) continue;
      }
      $new[] = $pieces;
    }
    $result = array();
    foreach ($new as $key => $pieces) {
      $geo = new Geo(array('ip' => $pieces[1], 'charset' => 'utf-8'));
      $geodata = $geo->get_value();
      $in_block = block(array($pieces[1], $pieces[2]));
      $in_danger = danger(array($pieces[1], $pieces[2]));
      $in_suspic = suspicious(array($pieces[1], $pieces[2]));
      $row_style = ' class="success"';
      if (substr($pieces[1], 0, 7) == '255.255') $mask_founded = true; else $mask_founded = false;
      if ($in_block || $mask_founded) $row_style = ' class="error"'; elseif ($in_danger || $in_suspic) $row_style = ' class="warning"';
      $notices = array();
      $groups_ids = get_groups_ids(array($pieces[1], $pieces[2]));
      if ($in_block) {
        $gggr = array();
        foreach ($groups_ids as $group_id) {
          if ($group_id != '1:0' && substr($group_id, 0, 1) == '1') $gggr[] = '"'.$groups[$group_id].'"';
        }
        $notices[] = '<span class="label label-important">Заблокированный.'.(count($gggr) > 0 ? ' Ярлык '.implode(', ', $gggr) : '').'</span>';
      }
      if ($mask_founded) $notices[] = '<span class="label label-important">IP похож на маску</span>';
      if ($in_danger) {
        $gggr = array();
        foreach ($groups_ids as $group_id) {
          if ($group_id != '2:0' && substr($group_id, 0, 1) == '2') $gggr[] = '"'.$groups[$group_id].'"';
        }
        $notices[] = '<span class="label label-warning">Опасный.'.(count($gggr) > 0 ? ' Ярлык '.implode(', ', $gggr) : '').'</span>';
      }
      if ($in_suspic) {
        $gggr = array();
        foreach ($groups_ids as $group_id) {
          if ($group_id != '3:0' && substr($group_id, 0, 1) == '3') $gggr[] = '"'.$groups[$group_id].'"';
        }
        $notices[] = '<span class="label label-warning">Подозрительный.'.(count($gggr) > 0 ? ' Ярлык '.implode(', ', $gggr) : '').'</span>';
      }
      foreach ($targets as $target) {
        if (strpos($pieces[3], $target[2]) !== false) {
          $notices[] = '<span class="label label-info">Найдена цель "'.$target[0].'"</span>';
          $row_style = ' class="info"';
        }
      }
      $result[] = array($pieces[0], '<tr'.$row_style.'>
        <td>'.date('d.m.Y H:i:s', $pieces[0]).'</td>
        <td>'.$pieces[1].'<br /><a href="https://www.nic.ru/whois/?query='.$pieces[1].'" target="_blank" rel="tooltip" title="IP whois"><i class="icon-search"></i></a>&nbsp;<a href="admin_panel.php?action=online&subaction=block_ip&ip='.$pieces[1].'" rel="tooltip" title="Заблокировать IP"><i class="icon-ban-circle"></i></a>&nbsp;<a href="admin_panel.php?action=online&subaction=danger_ip&ip='.$pieces[1].'" rel="tooltip" title=\'Добавить в "опасные"\'><i class="icon-warning-sign"></i></a>&nbsp;<a href="admin_panel.php?action=online&subaction=suspic_ip&ip='.$pieces[1].'" rel="tooltip" title=\'Добавить в "подозрительные"\'><i class="icon-eye-open"></i></a></td>
        <td>'.(isset($geodata['country']) ? $geodata['country'].'&nbsp;<a href="admin_panel.php?action=online&subaction=block_country&c='.$geodata['country'].'" rel="tooltip" title="Заблокировать страну"><i class="icon-ban-circle"></i></a>' : '??').' '.(isset($geodata['city']) ? $geodata['city'].'&nbsp;<a href="admin_panel.php?action=online&subaction=block_city&c='.$geodata['city'].'" rel="tooltip" title="Заблокировать город"><i class="icon-ban-circle"></i></a>' : '??').'</td>
        <td>'.(trim($pieces[4]) == '' ? '&nbsp;' : '<a href="'.$pieces[4].'" target="_blank">'.$pieces[4].'</a>').'</td>
        <td>'.(trim($pieces[3]) == '' ? '&nbsp;' : $pieces[3]).'</td>
        <td>'.(count($notices) > 0 ? implode('<br />', $notices) : '<span class="label label-success">OK</span>').'</td>
      </tr>');
    }

    if (count($result) > 0) {
      $result = array_reverse($result);
      echo php2js($result);
      break;
    }
    sleep(1);
  }
}

function php2js($a = false) {
  if (is_null($a)) return 'null';
  if ($a === false) return 'false';
  if ($a === true) return 'true';
  if (is_scalar($a)) {
    if (is_float($a)) {
      $a = str_replace(",", ".", strval($a));
    }
    static $jsonReplaces = array(
      array("\\", "/", "\n", "\t", "\r", "\b", "\f", '"'),
      array('\\\\', '\\/', '\\n', '\\t', '\\r', '\\b', '\\f', '\"')
    );
    return '"' . str_replace($jsonReplaces[0], $jsonReplaces[1], $a) . '"';
  }
  $isList = true;
  for ($i = 0, reset($a); $i < count($a); $i++, next($a)) {
    if (key($a) !== $i) {
      $isList = false;
      break;
    }
  }
  $result = array();
  if ($isList) {
    foreach ($a as $v) $result[] = php2js($v);
    return '[ ' . join(', ', $result) . ' ]';
  } else {
    foreach ($a as $k => $v) $result[] = php2js($k).': '.php2js($v);
    return '{ ' . join(', ', $result) . ' }';
  }
}
?>